# NH_MASTER-21 cleanup round v7: changed lines (2026-10-04)

Base: cleanup v6 (zip `9b1ca5d9…`). 51 items. Line numbers are v6 lines; every edit replaces a line in place.

## CH09-a — 1 items

- **R5-10437** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 522 — line 16 -> 28
  - before: `| C-WIS-SEP — Wellbeing / Identity / Security Separation (§25.5; cross-cutting); line 16 | empty_together | Boundary law with no independent I/O; not a step. Its consumer uses are explicit. No separate enforcement mechanism or failure response is specified for the law itself. |`
  - after: `| C-WIS-SEP — Wellbeing / Identity / Security Separation (§25.5; cross-cutting); line 28 | empty_together | Boundary law with no independent I/O; not a step. Its consumer uses are explicit. No separate enforcement mechanism or failure response is specified for the law itself. |`

## CH09-b — 3 items

- **R5-10438** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 983 — line 47 -> 56
  - before: `| C-OTHER.1 — Internal understanding and external disclosure; line 47 | prerequisite_review / Fails closed by | The prerequisite hit comes from the explicit privacy/authority gate already filled. The source gives the separation invariant, not an additional independent failure procedure for this boundary card; Fails closed by remains undecided without weakening Gated by. |`
  - after: `| C-OTHER.1 — Internal understanding and external disclosure; line 56 | prerequisite_review / Fails closed by | The prerequisite hit comes from the explicit privacy/authority gate already filled. The source gives the separation invariant, not an additional independent failure procedure for this boundary card; Fails closed by remains undecided without weakening Gated by. |`
- **R5-10439** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 984 — line 93 -> 106
  - before: `| C-OTHER.3 — Four access levels; line 93 | prerequisite_review / Gated by | The phrase 'requires a confirmed non-Ness identity and active PBR' defines one of the four classifications. It is not a separate external gate on the vocabulary card. SACL supplies the computed level, and the classified conditions and fallback are explicit in its children and Fails closed by. |`
  - after: `| C-OTHER.3 — Four access levels; line 106 | prerequisite_review / Gated by | The phrase 'requires a confirmed non-Ness identity and active PBR' defines one of the four classifications. It is not a separate external gate on the vocabulary card. SACL supplies the computed level, and the classified conditions and fallback are explicit in its children and Fails closed by. |`
- **R5-10440** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 985 — line 280 -> 293
  - before: `| C-OTHER.7 — Request-driven parent translation; line 280 | plain_together / Gated by | The plain Gated by line is Ness's request, a genuine human precondition with no separate card. It is allowed by lessons 3.3; the recipient and privacy gates are separately named. |`
  - after: `| C-OTHER.7 — Request-driven parent translation; line 293 | plain_together / Gated by | The plain Gated by line is Ness's request, a genuine human precondition with no separate card. It is allowed by lessons 3.3; the recipient and privacy gates are separately named. |`

## CH09-f — 3 items

- **R5-10441** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 3843 — line 52 -> 64
  - before: `| C-BGMM.1 — Narrow maintenance boundary; line 52 | empty_together | Owner boundary law, not an execution step. The word requires limits declared access; it is not an extra producer/gate. Read-only failure and direct prohibitions are explicit; actual entry gates are C-BGMM.8. |`
  - after: `| C-BGMM.1 — Narrow maintenance boundary; line 64 | empty_together | Owner boundary law, not an execution step. The word requires limits declared access; it is not an extra producer/gate. Read-only failure and direct prohibitions are explicit; actual entry gates are C-BGMM.8. |`
- **R5-10442** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 3844 — line 52 -> 65
  - before: `| C-BGMM.1 — Narrow maintenance boundary; line 52 | prerequisite_review / Gated by | Owner boundary law, not an execution step. The word requires limits declared access; it is not an extra producer/gate. Read-only failure and direct prohibitions are explicit; actual entry gates are C-BGMM.8. |`
  - after: `| C-BGMM.1 — Narrow maintenance boundary; line 65 | prerequisite_review / Gated by | Owner boundary law, not an execution step. The word requires limits declared access; it is not an extra producer/gate. Read-only failure and direct prohibitions are explicit; actual entry gates are C-BGMM.8. |`
- **R5-10443** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 3845 — line 75 -> 88
  - before: `| C-BGMM.2 — Protected purposes and factors; line 75 | prerequisite_review / Gated by | The classification owner states the five branches and intrinsic factor mapping. Each operative purpose card names its actual factor gates; the classifier needs no invented additional gate. |`
  - after: `| C-BGMM.2 — Protected purposes and factors; line 88 | prerequisite_review / Gated by | The classification owner states the five branches and intrinsic factor mapping. Each operative purpose card names its actual factor gates; the classifier needs no invented additional gate. |`

## CH09-h — 8 items

- **R5-10444** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 5264 — line 86 -> 101
  - before: `| C-ENROLL.2 — Six-owner prerequisite check; line 86 | prerequisite_review / Gated by | The all-six conjunction defines this check itself. Its actual owner inputs are named in Fed by and failure is explicit; no second gating authority is invented from its own checking logic. |`
  - after: `| C-ENROLL.2 — Six-owner prerequisite check; line 101 | prerequisite_review / Gated by | The all-six conjunction defines this check itself. Its actual owner inputs are named in Fed by and failure is explicit; no second gating authority is invented from its own checking logic. |`
- **R5-10445** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 5265 — line 142 -> 155
  - before: `| C-ENROLL.2.2 — Completed first-code prerequisite; line 142 | prerequisite_review / Gated by | Saved/verified/tested/activated are the condition being checked, with the actual handover owner in Fed by. Failure is explicit; a duplicate self-condition is not a TOGETHER gate. |`
  - after: `| C-ENROLL.2.2 — Completed first-code prerequisite; line 155 | prerequisite_review / Gated by | Saved/verified/tested/activated are the condition being checked, with the actual handover owner in Fed by. Failure is explicit; a duplicate self-condition is not a TOGETHER gate. |`
- **R5-10446** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 5266 — line 165 -> 178
  - before: `| C-ENROLL.2.3 — Inert initial-material prerequisite; line 165 | prerequisite_review / Gated by | The two inertness facts define prerequisite 3 and their owners are named. Either missing/contradictory fact already fails closed; no additional gate is sourced. |`
  - after: `| C-ENROLL.2.3 — Inert initial-material prerequisite; line 178 | prerequisite_review / Gated by | The two inertness facts define prerequisite 3 and their owners are named. Either missing/contradictory fact already fails closed; no additional gate is sourced. |`
- **R5-10447** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 5267 — line 521 -> 534
  - before: `| C-ENROLL.3.1 — Durable explicit-begin event; line 521 | prerequisite_review / Gated by | The scan also sees the new-begin requirement in the using fresh-session card. This card owns the actual durable choice event and its pre-snapshot crash outcome; it does not manufacture a separate event gate. |`
  - after: `| C-ENROLL.3.1 — Durable explicit-begin event; line 534 | prerequisite_review / Gated by | The scan also sees the new-begin requirement in the using fresh-session card. This card owns the actual durable choice event and its pre-snapshot crash outcome; it does not manufacture a separate event gate. |`
- **R5-10448** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 5268 — line 575 -> 588
  - before: `| C-ENROLL.3.3 — Prospective enrollment session identity; line 575 | prerequisite_review / Gated by | Prospective-versus-opened status is the identity's own meaning. The actual session commit remains C-ENROLL.4.4; Fails closed explicitly states no commit means no session, without turning that definition into a second identity gate. |`
  - after: `| C-ENROLL.3.3 — Prospective enrollment session identity; line 588 | prerequisite_review / Gated by | Prospective-versus-opened status is the identity's own meaning. The actual session commit remains C-ENROLL.4.4; Fails closed explicitly states no commit means no session, without turning that definition into a second identity gate. |`
- **R5-10449** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 5269 — line 724 -> 737
  - before: `| C-ENROLL.4.3 — Durable authorization chain and binding; line 724 | prerequisite_review / Gated by | The proof chain is verified by its own operation, with actual BAI input named. Missing or unverifiable proof/binding already prevents opening; using-card requirements do not add another binding authority. |`
  - after: `| C-ENROLL.4.3 — Durable authorization chain and binding; line 737 | prerequisite_review / Gated by | The proof chain is verified by its own operation, with actual BAI input named. Missing or unverifiable proof/binding already prevents opening; using-card requirements do not add another binding authority. |`
- **R5-10450** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 5270 — line 1033 -> 1046
  - before: `| C-ENROLL.4.5 — Opening duplicate barriers; line 1033 | prerequisite_review / Gated by | The card groups the eight source-defined barriers, each separately placed. It names actual claim/proof inputs and explicit refusal/revocation, with no extra outer barrier invented. |`
  - after: `| C-ENROLL.4.5 — Opening duplicate barriers; line 1046 | prerequisite_review / Gated by | The card groups the eight source-defined barriers, each separately placed. It names actual claim/proof inputs and explicit refusal/revocation, with no extra outer barrier invented. |`
- **R5-10451** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 5271 — line 1240 -> 1253
  - before: `| C-ENROLL.4.6 — Spent proof without an opened session; line 1240 | prerequisite_review / Gated by | New begin and fresh token are requirements for a later attempt, not a gate to recording this already-spent no-session abort. The current stopped outcome is explicit. |`
  - after: `| C-ENROLL.4.6 — Spent proof without an opened session; line 1253 | prerequisite_review / Gated by | New begin and fresh token are requirements for a later attempt, not a gate to recording this already-spent no-session abort. The current stopped outcome is explicit. |`

## CH10-c — 7 items

- **R5-10452** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 1363 — line 345 -> 357
  - before: `| C-22.4.1 — Physical threshold values and mechanics; line 345 | empty_together | Named open threshold/mechanics slot, not an executable step; no numeric or enforcement values are invented. |`
  - after: `| C-22.4.1 — Physical threshold values and mechanics; line 357 | empty_together | Named open threshold/mechanics slot, not an executable step; no numeric or enforcement values are invented. |`
- **R5-10453** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 1364 — line 395 -> 404
  - before: `| C-22.5.1 — Actions contrary to demonstrated values; line 395 | prerequisite_review / Fails closed by | The broader pattern requirement is already a named gate on C-22.5. The source does not specify an additional failure mechanism for an individual warning-pattern input. |`
  - after: `| C-22.5.1 — Actions contrary to demonstrated values; line 404 | prerequisite_review / Fails closed by | The broader pattern requirement is already a named gate on C-22.5. The source does not specify an additional failure mechanism for an individual warning-pattern input. |`
- **R5-10454** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 1365 — line 439 -> 448
  - before: `| C-22.5.3 — Ness-specific language and reasoning shift; line 439 | prerequisite_review / Fails closed by | The sustained personal-pattern condition is already in Gated by. No separate failure outcome for the language/reasoning input is supplied. |`
  - after: `| C-22.5.3 — Ness-specific language and reasoning shift; line 448 | prerequisite_review / Fails closed by | The sustained personal-pattern condition is already in Gated by. No separate failure outcome for the language/reasoning input is supplied. |`
- **R5-10455** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 1366 — line 627 -> 639
  - before: `| C-22.6.5 — Tier selection and transition mechanics; line 627 | empty_together | The source supplies tiers but not exact selection/transition mechanics. This open slot is not a step and is fully registered. |`
  - after: `| C-22.6.5 — Tier selection and transition mechanics; line 639 | empty_together | The source supplies tiers but not exact selection/transition mechanics. This open slot is not a step and is fully registered. |`
- **R5-10456** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 1367 — line 792 -> 804
  - before: `| C-22.9.2 — Healthy review queue for one month; line 792 | prerequisite_review / Gated by | This card is the one-month prerequisite itself; its failure line defers creation. No second gate on the prerequisite or invented queue-health metric is added. |`
  - after: `| C-22.9.2 — Healthy review queue for one month; line 804 | prerequisite_review / Gated by | This card is the one-month prerequisite itself; its failure line defers creation. No second gate on the prerequisite or invented queue-health metric is added. |`
- **R5-10457** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 1368 — line 836 -> 848
  - before: `| C-22.9.4 — Advisory and non-diagnostic boundary; line 836 | prerequisite_review / Gated by | The advisory restriction is the condition being defined; its failure line requires that boundary. The unresolved source tension remains marked rather than converted into a new gate. |`
  - after: `| C-22.9.4 — Advisory and non-diagnostic boundary; line 848 | prerequisite_review / Gated by | The advisory restriction is the condition being defined; its failure line requires that boundary. The unresolved source tension remains marked rather than converted into a new gate. |`
- **R5-10458** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 1369 — line 1128 -> 1139
  - before: `| C-22.13.3 — Clinical-output mechanics and schema; line 1128 | empty_together | Only PDF/chart forms are restored. This card registers missing mechanics/schema; no executable clinical generation or export step is invented. |`
  - after: `| C-22.13.3 — Clinical-output mechanics and schema; line 1139 | empty_together | Only PDF/chart forms are restored. This card registers missing mechanics/schema; no executable clinical generation or export step is invented. |`

## CH10-d — 2 items

- **R5-10459** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 1014 — line 318 -> 331
  - before: `| C-23.5.1 — Pre-send confirmation; line 318 | plain_together / Gated by | Plain gate is the explicit fingerprint/Face ID/PIN confirmation before sending, a personal act rather than a new component. |`
  - after: `| C-23.5.1 — Pre-send confirmation; line 331 | plain_together / Gated by | Plain gate is the explicit fingerprint/Face ID/PIN confirmation before sending, a personal act rather than a new component. |`
- **R5-10460** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 1015 — line 430 -> 443
  - before: `| C-23.6.2 — Raw phone-command prohibition; line 430 | plain_together / Gated by | Plain gate is the source's verified raw-run-path removal prerequisite before go-live; no enforcement or removal implementation is invented. |`
  - after: `| C-23.6.2 — Raw phone-command prohibition; line 443 | plain_together / Gated by | Plain gate is the source's verified raw-run-path removal prerequisite before go-live; no enforcement or removal implementation is invented. |`

## CH10-e — 22 items

- **R5-10461** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10449 — line 391 -> 390
  - before: `| C-19.2.3 — Separate World-opening confirmation; line 391 | plain_together / Gated by | The plain gate is the separate confirmation act itself; the earlier verification/question stages have their own named cards. |`
  - after: `| C-19.2.3 — Separate World-opening confirmation; line 390 | plain_together / Gated by | The plain gate is the separate confirmation act itself; the earlier verification/question stages have their own named cards. |`
- **R5-10462** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10450 — line 730 -> 728
  - before: `| C-19.8 — Reading the room; line 730 | plain_together / Gated by | The plain gate is Ness’s requested approval before big form changes, a personal act with no separate component. |`
  - after: `| C-19.8 — Reading the room; line 728 | plain_together / Gated by | The plain gate is Ness’s requested approval before big form changes, a personal act with no separate component. |`
- **R5-10463** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10451 — line 842 -> 840
  - before: `| C-19.10.1 — Inspectable pattern history; line 842 | prerequisite_review / Fails closed by | The parent requirement is gradual inspectability. The card carries its required contents and prohibition, but the source specifies no distinct failure/recovery outcome for an inspection-history object. |`
  - after: `| C-19.10.1 — Inspectable pattern history; line 840 | prerequisite_review / Fails closed by | The parent requirement is gradual inspectability. The card carries its required contents and prohibition, but the source specifies no distinct failure/recovery outcome for an inspection-history object. |`
- **R5-10464** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10452 — line 1094 -> 1104
  - before: `| C-19.14 — Open World experience choices; line 1094 | empty_together | A container of explicit open experience slots, not an executable step. Candidate answers remain separate and do not close governing-source gaps. |`
  - after: `| C-19.14 — Open World experience choices; line 1104 | empty_together | A container of explicit open experience slots, not an executable step. Candidate answers remain separate and do not close governing-source gaps. |`
- **R5-10465** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10453 — line 1116 -> 1126
  - before: `| C-19.14.1 — Open individual-space defaults; line 1116 | empty_together | Open individual-space defaults; accepted options do not select either default, so no runtime relation is invented. |`
  - after: `| C-19.14.1 — Open individual-space defaults; line 1126 | empty_together | Open individual-space defaults; accepted options do not select either default, so no runtime relation is invented. |`
- **R5-10466** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10454 — line 1138 -> 1148
  - before: `| C-19.14.2 — Open entry and navigation details; line 1138 | empty_together | Open governing-source entry/navigation choices; later candidate directions stay separate and do not provide a settled transition mechanism. |`
  - after: `| C-19.14.2 — Open entry and navigation details; line 1148 | empty_together | Open governing-source entry/navigation choices; later candidate directions stay separate and do not provide a settled transition mechanism. |`
- **R5-10467** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10455 — line 1160 -> 1170
  - before: `| C-19.14.3 — Open simulation interior; line 1160 | empty_together | Open governing-source simulation-experience choices; no chosen mode or lifecycle mechanism is inferred from the list. |`
  - after: `| C-19.14.3 — Open simulation interior; line 1170 | empty_together | Open governing-source simulation-experience choices; no chosen mode or lifecycle mechanism is inferred from the list. |`
- **R5-10468** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10456 — line 1182 -> 1192
  - before: `| C-19.14.4 — Open physical interaction details; line 1182 | empty_together | Open governing-source physical-input details, not a step; later candidate answer content retains its own status. |`
  - after: `| C-19.14.4 — Open physical interaction details; line 1192 | empty_together | Open governing-source physical-input details, not a step; later candidate answer content retains its own status. |`
- **R5-10469** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10457 — line 1204 -> 1214
  - before: `| C-19.14.5 — Open learning-history interaction; line 1204 | empty_together | Open governing-source learning-history interface details; candidate answers do not silently close this V10 slot. |`
  - after: `| C-19.14.5 — Open learning-history interaction; line 1214 | empty_together | Open governing-source learning-history interface details; candidate answers do not silently close this V10 slot. |`
- **R5-10470** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10458 — line 1226 -> 1236
  - before: `| C-19.14.6 — Open visual and approval language; line 1226 | empty_together | Unselected visual/approval language, not an executable step or invented authority mechanism. |`
  - after: `| C-19.14.6 — Open visual and approval language; line 1236 | empty_together | Unselected visual/approval language, not an executable step or invented authority mechanism. |`
- **R5-10471** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10459 — line 1248 -> 1258
  - before: `| C-19.14.7 — Provisional spatial configuration; line 1248 | empty_together | Provisional context only; source supplies no final relationship selecting the spatial configuration. |`
  - after: `| C-19.14.7 — Provisional spatial configuration; line 1258 | empty_together | Provisional context only; source supplies no final relationship selecting the spatial configuration. |`
- **R5-10472** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10460 — line 1432 -> 1442
  - before: `| C-19.15.7 — Open room-start mechanics; line 1432 | empty_together | Accepted policy expressly leaves these room-start mechanisms open; an open-scope card has no selected runtime relation. |`
  - after: `| C-19.15.7 — Open room-start mechanics; line 1442 | empty_together | Accepted policy expressly leaves these room-start mechanisms open; an open-scope card has no selected runtime relation. |`
- **R5-10473** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10461 — line 1615 -> 1622
  - before: `| C-19.16.7 — Unchosen ordinary-chat colours; line 1615 | empty_together | The accepted decision leaves colour/palette/theme values unset; no mechanism or dependency is invented. |`
  - after: `| C-19.16.7 — Unchosen ordinary-chat colours; line 1622 | empty_together | The accepted decision leaves colour/palette/theme values unset; no mechanism or dependency is invented. |`
- **R5-10474** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10462 — line 1637 -> 1644
  - before: `| C-19.16.8 — Later ordinary-chat extras; line 1637 | empty_together | Later extras are expressly unselected, not rejected; no card behavior is imported into ordinary chat. |`
  - after: `| C-19.16.8 — Later ordinary-chat extras; line 1644 | empty_together | Later extras are expressly unselected, not rejected; no card behavior is imported into ordinary chat. |`
- **R5-10475** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10463 — line 1682 -> 1689
  - before: `| C-19.16.10 — Open ordinary-chat details; line 1682 | empty_together | Named open ordinary-chat details, not a workflow step or selected backend/UI mechanism. |`
  - after: `| C-19.16.10 — Open ordinary-chat details; line 1689 | empty_together | Named open ordinary-chat details, not a workflow step or selected backend/UI mechanism. |`
- **R5-10476** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10464 — line 2044 -> 2037
  - before: `| C-19.17.14 — Card summoning; line 2044 | prerequisite_review / Fails closed by | The keyword require appears in a prohibition against forcing a bespoke control system. No card-summoning failure response is specified; the reference boundary is already a named gate. |`
  - after: `| C-19.17.14 — Card summoning; line 2037 | prerequisite_review / Fails closed by | The keyword require appears in a prohibition against forcing a bespoke control system. No card-summoning failure response is specified; the reference boundary is already a named gate. |`
- **R5-10477** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10465 — line 2168 -> 2161
  - before: `| C-19.17.18.1 — Placement point identity; line 2168 | prerequisite_review / Fails closed by | The used-point identity requirement is present in Must never and the placement-meaning gate. The source supplies no distinct missing-field failure mechanism or schema. |`
  - after: `| C-19.17.18.1 — Placement point identity; line 2161 | prerequisite_review / Fails closed by | The used-point identity requirement is present in Must never and the placement-meaning gate. The source supplies no distinct missing-field failure mechanism or schema. |`
- **R5-10478** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10466 — line 2190 -> 2183
  - before: `| C-19.17.18.2 — Placement conversation target; line 2190 | prerequisite_review / Fails closed by | The conversation-target requirement is present in Must never and the parent gate. No separate failure outcome or serialization is invented. |`
  - after: `| C-19.17.18.2 — Placement conversation target; line 2183 | prerequisite_review / Fails closed by | The conversation-target requirement is present in Must never and the parent gate. No separate failure outcome or serialization is invented. |`
- **R5-10479** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10467 — line 2234 -> 2227
  - before: `| C-19.17.18.4 — Placement conversation context; line 2234 | prerequisite_review / Fails closed by | The relevant-context requirement is present in Must never and the parent gate. The experience-level source gives no separate failure mechanism. |`
  - after: `| C-19.17.18.4 — Placement conversation context; line 2227 | prerequisite_review / Fails closed by | The relevant-context requirement is present in Must never and the parent gate. The experience-level source gives no separate failure mechanism. |`
- **R5-10480** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10468 — line 2380 -> 2385
  - before: `| C-19.17.23 — Open checkpoint experience details; line 2380 | empty_together | Named open checkpoint visuals and navigation choices, not executable steps; candidate experience content does not select them. |`
  - after: `| C-19.17.23 — Open checkpoint experience details; line 2385 | empty_together | Named open checkpoint visuals and navigation choices, not executable steps; candidate experience content does not select them. |`
- **R5-10481** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10469 — line 2402 -> 2407
  - before: `| C-19.17.24 — Open card mechanics; line 2402 | empty_together | Named open card/integration mechanics, not executable steps; underlying owners remain canonical. |`
  - after: `| C-19.17.24 — Open card mechanics; line 2407 | empty_together | Named open card/integration mechanics, not executable steps; underlying owners remain canonical. |`
- **R5-10482** FIX_REGISTER_POINTER [RECHECK5-PARTC-001] v6 line 10471 — line 2897 -> 2895
  - before: `| C-19.19.3.1 — nh_entity_id [proposed]; line 2897 | prerequisite_review / Fails closed by | The example entity reference is protected by a prohibition and its lightweight-reference gate. The source defines no missing-reference failure class or recovery. |`
  - after: `| C-19.19.3.1 — nh_entity_id [proposed]; line 2895 | prerequisite_review / Fails closed by | The example entity reference is protected by a prohibition and its lightweight-reference gate. The source defines no missing-reference failure class or recovery. |`

## CH12-a — 1 items

- **R5-10483** REGENERATE_APPENDIX sha256:7b2a62203b75dff9dc83eb00cacc9701b5b83b72eca4698edfbab70bc19a236f → sha256:6e8eaf8816673cb007bc36b82045a6e33a86e0e94d6548d2cf69c77482ec619f. chapter fingerprints refreshed for the v7 chapters (7 rows); v7 moves no line and changes no gap, citation or conflict text; before = the v6 file

## CH12-b — 1 items

- **R5-10484** REGENERATE_APPENDIX sha256:b107e569a357847cb0fff9e9a08d1ca0566d3162de2002f88dfd13e65030a373 → sha256:5b2181e411417b531ad81f3db1f5d98861bdbe27c2839c0da5f134bde0677bd2. chapter fingerprints refreshed for the v7 chapters (7 rows); v7 moves no line and changes no gap, citation or conflict text; before = the v6 file

## CH12-c — 1 items

- **R5-10485** REGENERATE_APPENDIX sha256:e88001c5e20529e198171adf7bfb5ec57cc6086410a4ccd980ee46c9c7280dc7 → sha256:640043e45771a9211035eacfad5d9a11669e10fbef48d6f3ddf37b5c4dc92df5. chapter fingerprints refreshed for the v7 chapters (7 rows); v7 moves no line and changes no gap, citation or conflict text; before = the v6 file

## CH12-d — 1 items

- **R5-10486** REGENERATE_APPENDIX sha256:b8b3e9f5382e17916a60b543db0d4ae6d4a7423b6a4c962eea5d71c9cce5fbd9 → sha256:6eda8e8c44be0bb2d6e6cd0bda66a0e064190f6d8085bfc175341d242aa3340e. chapter fingerprints refreshed for the v7 chapters (7 rows); v7 moves no line and changes no gap, citation or conflict text; before = the v6 file

## CH12-e — 1 items

- **R5-10487** REGENERATE_APPENDIX sha256:0774d0fd9d26e73bfe6914e6951672786b333121cb3cd2f35b4246cd668a0625 → sha256:8b8c4e523582d4a2703e3d37fb35e808a9c38d929c38fb3c13260f9bbf88e6d5. chapter fingerprints refreshed for the v7 chapters (7 rows); v7 moves no line and changes no gap, citation or conflict text; before = the v6 file

