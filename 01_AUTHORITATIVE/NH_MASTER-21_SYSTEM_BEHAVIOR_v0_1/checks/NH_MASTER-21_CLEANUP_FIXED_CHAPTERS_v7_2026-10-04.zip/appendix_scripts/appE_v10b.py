import sys; sys.path.insert(0,'/home/claude/m21/v6'); sys.path.insert(1,'/home/claude/m21/v2'); sys.path.insert(2,'/home/claude/m21/tools')
import v6lib as v3lib, m21, re, collections, json, v2check
from appE_index import natkey, ranges, CHS
b=v3lib.Build(); cards=v2check.parse(b.lines)
def cells(s): return [x.strip() for x in re.split(r'(?<!\\)\|',s.strip())[1:-1]]
D=json.load(open('appE_occ.json'))
def tt(w): return None if not w else (w[0], tuple(w[1]) if isinstance(w[1],list) else w[1])
occ={k:[(x[0],x[1],tt(x[2])) for x in v] for k,v in D['occ'].items()}
V10=open('/home/claude/pin/01_AUTHORITATIVE/NH_MASTER-20_CORRECTED_v10.md',encoding='utf-8').read().split('\n')
H=[(n,s) for n,s in enumerate(V10,1) if s.startswith('## ') or s.startswith('### ')]
norm=lambda t: re.sub(r'[^A-Z0-9]+',' ',t.upper()).strip()
def token(s):
    m=re.match(r'^#{2,3}\s+(?:§)?(\d+[A-Z]?(?:-[A-Z])?(?:\.\d+)*)\.?\s',s); return m.group(1) if m else None
tok={}
for n,s in H:
    t=token(s)
    if t and t not in tok: tok[t]=n
def heading_for(c):
    x=c.strip('[]')[3:].strip(); m=re.match(r'^§(\S+?)(?:\s*/\s*(.*))?$',x)
    if m:
        t=m.group(1).rstrip('.'); sub=m.group(2); t=re.split(r'(?<=\d)(?= item)',t)[0]
        base=tok.get(t) or tok.get(t.split('.')[0])
        if not base: return None
        if sub:
            ns=norm(sub); end=next((n for n,s in H if n>base and s.startswith('## ')),10**9)
            for n,s in H:
                if base<n<end and norm(re.sub(r'^#+\s*','',s)).startswith(ns): return n
        return base
    m=re.match(r'^/\s*(.*)$',x)
    if m:
        ns=norm(m.group(1))
        for n,s in H:
            if norm(re.sub(r'^#+\s*','',s)).startswith(ns): return n
    return None
cite_h=collections.defaultdict(list)
for c,ls in occ.items():
    if c.startswith('[V10'):
        h=heading_for(c)
        if h: cite_h[h].extend(ls)
def owners(ls):
    o=set()
    for (ch,n,w) in ls:
        if w: o.update([w[1]] if w[0] in ('card','path') else w[1])
    return o
def fmt(o): return ', '.join(f'`{x}`' for x in sorted(o,key=natkey))
def in_tree(x,roots):
    return any((r[1:]==x) if r.startswith('=') else (x==r or x.startswith(r+'.')) for r in roots)
def sec_occ(sec,roots):
    out=[]
    for c,ls in occ.items():
        if c.startswith('[V10 §'+sec) and (len(c)==len('[V10 §'+sec)+1 or not c[len('[V10 §'+sec)].isdigit()):
            for (ch,n,w) in ls:
                if w and any(in_tree(x,roots) for x in ([w[1]] if w[0] in ('card','path') else w[1])): out.append((ch,n,w))
    return out
V1=m21.lines('CH12-e','v1'); i=V1.index('<!-- BEGIN DATA E V10 -->'); j=V1.index('<!-- END DATA E V10 -->')
R=[cells(s) for s in V1[i+3:j]]
L8=b.lines('CH08-b'); L9=b.lines('CH09-i'); Le=b.lines('CH09-e')
M6={'ACCESS':(['=C-9','C-9.1'],'C-9 and C-9.1'),'VOICE':(['C-9.2'],'C-9.2 and six stages'),'PHONE':(['C-9.3'],'C-9.3/.3.1'),'REHEARSAL':(['C-9.4'],'C-9.4/.4.1')}
esc=lambda x: x.replace('|','\\|')
out=[]; stat=collections.Counter()
for k in R:
    ln=int(k[0]); head=k[1]; place=k[2]; meth=k[3]
    msent=re.split(r'\s(?=CH\d\d(?:-[a-z])?:\d|No matching source locator)',meth)[0].strip()
    if meth.startswith('Exact section or named-subheading'):
        ls=cite_h.get(ln,[]); o=owners(ls)
        np=fmt(o) if o else 'NOT PLACED: no finished chapter cites this exact section or named subheading.'
        nm=msent+' '+(ranges(ls) if ls else 'No matching source locator.'); stat['M1']+=1
    elif meth.startswith('Aggregate of this parent'):
        t=token(head); subs=[n for n,s in H if (token(s) or '').startswith(t+'.')]
        ls=list(cite_h.get(ln,[]))
        for n in subs: ls+=cite_h.get(n,[])
        np=fmt(owners(ls)); nm=msent+' '+ranges(ls); stat['M5']+=1
    elif meth.startswith('Explicit CH08-b'):
        dn=re.search(r'DECISION (\d+)',head).group(1)
        land=[n for n,s in enumerate(L8,1) if re.match(r'^\| V10 §7R Decision '+dn+r'[ ;|]',s) and not re.match(r'^\| V10 §7R Decision '+dn+r'\d',s)]; assert len(land)==1,(head,land)
        rts=[f'C-7R.{dn}']
        ls=sec_occ('7R',rts)+cite_h.get(ln,[]); o=set(x for x in owners(ls) if in_tree(x,rts))|owners(cite_h.get(ln,[]))
        np=fmt(o); nm=msent+' '+ranges(ls)+f' Explicit landing: CH08-b:{land[0]}.'; stat['M2']+=1
    elif meth.startswith('Explicit CH09-i'):
        key=next(kk for kk in M6 if kk in head.upper()); rts,marker=M6[key]
        land=[n for n,s in enumerate(L9,1) if s.startswith('| V10 §9') and marker in s]; assert len(land)==2,(head,land)
        ls=sec_occ('9',rts)+cite_h.get(ln,[]); o=set(x for x in owners(ls) if in_tree(x,rts))|owners(cite_h.get(ln,[]))
        np=fmt(o); nm=msent+' '+ranges(ls)+f' Explicit landing: CH09-i:{land[0]},{land[1]}.'; stat['M6']+=1
    elif meth.startswith('Exact normalized source-title'):
        hn=norm(re.sub(r'^#+\s*','',head))
        cand=[(n,s) for n,s in enumerate(Le,1) if s.startswith('### C-BAI.') and norm(s.split(' — ',1)[1])==hn]; assert len(cand)==1,(head,cand)
        cid=re.match(r'^### (C-\S+) — ',cand[0][1]).group(1)
        ls=sec_occ('25.6',[cid])+cite_h.get(ln,[]); o=set(x for x in owners(ls) if in_tree(x,[cid]))|owners(cite_h.get(ln,[]))
        np=fmt(o); nm=msent+' '+ranges(ls)+f' Explicit landing: CH09-e:{cand[0][0]}.'; stat['M7']+=1
    else:
        np=place; nm=meth; stat['kept']+=1
    out.append([str(ln),head,np,nm])
print(dict(stat))
json.dump(out,open('appE_v10rows.json','w'),ensure_ascii=False)
for r in out:
    if 'PHONE' in r[1] or 'DECISION 1 —' in r[1] or 'Biometric Lease' in r[1]: print(r[0],r[1][:40],'|',r[2][:160],'|',r[3][-150:])
