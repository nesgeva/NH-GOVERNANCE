"""Master-21 cleanup round v4 builder (base: the v3 files; line numbers refer to v3) (Claude, 2026-10-04).
Starts from the v1 chapters and applies v2 fixes. Every line keeps its v1 line
number (None for lines inserted in v2, with the v1 anchor they follow).
Every change is logged as a record item; state is saved to disk after each pass.
"""
import sys, json, os, re, copy
sys.path.insert(0, '/home/claude/m21/tools')
import m21

STATE = '/home/claude/m21/v6/state_v6.json'
OUT = '/home/claude/m21/v6/out'
BASE = '/home/claude/m21/v5/deliver'

class Build:
    def __init__(self, fresh=False):
        if not fresh and os.path.exists(STATE):
            s = json.load(open(STATE, encoding='utf-8'))
            self.docs, self.items, self.next_id, self.passes = s['docs'], s['items'], s['next_id'], s['passes']
        else:
            # each line: [v1_line_or_None, text, anchor_v1_line, item_id_if_inserted]
            self.docs = {ch: [[i+1, s, None, None] for i, s in enumerate(open(f'{BASE}/{m21.PRE}{ch}.md', encoding='utf-8').read().split(chr(10)))] for ch in m21.CH}
            self.items = []
            self.next_id = 10052
            self.passes = []

    def save(self, pass_name=None):
        if pass_name and pass_name not in self.passes:
            self.passes.append(pass_name)
        tmp = STATE + '.tmp'
        json.dump({'docs': self.docs, 'items': self.items, 'next_id': self.next_id, 'passes': self.passes},
                  open(tmp, 'w', encoding='utf-8'), ensure_ascii=False)
        os.replace(tmp, STATE)

    def lines(self, ch):
        return [x[1] for x in self.docs[ch]]

    def _new_id(self):
        i = f'R5-{self.next_id:05d}'
        self.next_id += 1
        return i

    def _find_item(self, iid):
        for it in reversed(self.items):
            if it['id'] == iid:
                return it

    def edit(self, ch, idx, new, action, findings, rule, card=None, note=None):
        """idx: 0-based index into current doc lines."""
        ln = self.docs[ch][idx]
        old = ln[1]
        if old == new:
            return None
        if ln[0] is None and ln[3]:
            # line inserted in v2: fold into its insertion item
            it = self._find_item(ln[3])
            k = it['after'].index(old)
            it['after'][k] = new
            for f in findings:
                if f not in it['finding_ids']:
                    it['finding_ids'].append(f)
            it.setdefault('later_edits', []).append(action)
            ln[1] = new
            return it['id']
        iid = self._new_id()
        it = {'id': iid, 'chapter': ch, 'line': ln[0], 'before': old, 'after': new,
              'action': action, 'finding_ids': list(findings), 'rule': rule}
        if card: it['card'] = card
        if note: it['note'] = note
        if ln[0] is None:  # inserted by v1 cleanup? (cannot happen: v1 lines all have numbers)
            it['line'] = None
        self.items.append(it)
        ln[1] = new
        return iid

    def insert_after(self, ch, idx, new_lines, action, findings, rule, card=None, note=None):
        """insert new_lines after current index idx (0-based). Anchor = nearest v1 line at or above."""
        j = idx
        while j >= 0 and self.docs[ch][j][0] is None:
            j -= 1
        anchor = self.docs[ch][j][0] if j >= 0 else 0
        iid = self._new_id()
        it = {'id': iid, 'chapter': ch, 'line': None, 'inserted_after': anchor, 'before': None,
              'after': list(new_lines), 'action': action, 'finding_ids': list(findings), 'rule': rule}
        if card: it['card'] = card
        if note: it['note'] = note
        self.items.append(it)
        for k, s in enumerate(new_lines):
            self.docs[ch].insert(idx + 1 + k, [None, s, anchor, iid])
        return iid

    def write_out(self):
        os.makedirs(OUT, exist_ok=True)
        for ch in m21.CH:
            with open(f'{OUT}/{m21.PRE}{ch}.md', 'w', encoding='utf-8', newline='\n') as f:
                f.write('\n'.join(self.lines(ch)))
