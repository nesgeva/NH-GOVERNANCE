import sys; sys.path.insert(0,'.'); sys.path.insert(0,'/home/claude/m21/tools')
import v2lib, m21, re, collections
CARD=re.compile(r'^### (C-[A-Za-z0-9][A-Za-z0-9\-]*(?:\.[0-9A-Za-z]+)*) — (.*)$')
BOX=re.compile(r'^- (What it is|Takes in|Does|Gives out|Must never|Fails closed by|Fed by|Gated by|Changes):\s?(.*)$')
ROW=re.compile(r'^\| (\d+) · ([A-Z0-9\-]+(?: [A-Z]+)?) \| (.*)$')
USEDIN=re.compile(r'^(C-[A-Za-z0-9][A-Za-z0-9\-]*(?:\.[0-9A-Za-z]+)*)(?= — |,|;| |$)')
ANYID=re.compile(r'(?<![A-Za-z0-9\.\-])(C-[A-Za-z0-9][A-Za-z0-9\-]*(?:\.[0-9A-Za-z]+)*) — ')
def parse(get):
    cards={}
    for ch in m21.CH:
        L=get(ch); cur=None
        for n,s in enumerate(L,1):
            m=CARD.match(s)
            if m: cur={'id':m.group(1),'title':m.group(2),'ch':ch,'start':n,'boxes':[],'ub':[],'ubh':None,'stamp':None}; cards[cur['id']]=cur; continue
            if cur is None: continue
            if s.startswith('## ') or s.startswith('<!-- END'): cur=None; continue
            if s.startswith('Stamp:') and cur['stamp'] is None: cur['stamp']=s.split('Stamp:')[1].split('Source:')[0].strip()
            bm=BOX.match(s)
            if bm: cur['boxes'].append((n,bm.group(1),bm.group(2))); continue
            if s.startswith('USED BY'): cur['ubh']=n
            rm=ROW.match(s)
            if rm and cur['ubh']: cur['ub'].append((n,int(rm.group(1)),rm.group(2),rm.group(3)))
    return cards
def names_in(text,cards):
    out=[]; t=text.replace('`','')
    for m in ANYID.finditer(t):
        c=cards.get(m.group(1))
        if c and t[m.end():].startswith(c['title'].replace('`','')): out.append(m.group(1))
    return out
def run(get):
    cards=parse(get); res={}
    BOXES=['What it is','Takes in','Does','Gives out','Must never','Fails closed by','Fed by','Gated by','Changes']
    bad_order=0; bad_num=0; mixed=0; nrows=0
    for c in cards.values():
        seq=[]
        for _,bx,_ in c['boxes']:
            if not seq or seq[-1]!=bx: seq.append(bx)
        if seq!=BOXES: bad_order+=1
        nums=[u[1] for u in c['ub']]; nrows+=len(nums)
        if nums!=list(range(1,len(nums)+1)): bad_num+=1
        cells=[u[3].split(' | ')[0].strip() for u in c['ub']]
        if 'NOT DECIDED' in cells and any(x!='NOT DECIDED' for x in cells): mixed+=1
    res['cards']=len(cards); res['box order bad']=bad_order; res['USED BY rows']=nrows; res['numbering bad']=bad_num; res['NOT DECIDED mixed with rows']=mixed
    tog=set(); fwd_missing=[]
    ub=set()
    for c in cards.values():
        for (n,num,st,rest) in c['ub']:
            m=USEDIN.match(rest.split(' | ')[0].strip())
            if m: ub.add((c['id'],m.group(1)))
    for c in cards.values():
        for (n,bx,t) in c['boxes']:
            if bx in ('Fed by','Gated by','Changes'):
                for bb in names_in(t,cards):
                    if bb!=c['id']:
                        tog.add((c['id'],bb))
                        if (bb,c['id']) not in ub: fwd_missing.append((c['ch'],n,c['id'],bb))
    # continuation credit: any outside-card table row naming both ids
    cont=set()
    for ch in m21.CH:
        L=get(ch); inc=set()
        for c in cards.values():
            pass
        for s in L:
            if s.startswith('| ') and ' — ' in s and not ROW.match(s):
                ids=[m.group(1) for m in ANYID.finditer(s.replace('`',''))]
                for x in ids:
                    for y in ids:
                        if x!=y: cont.add((x,y))
    rev=collections.Counter(); rev_list=[]
    for c in cards.values():
        for (n,num,st,rest) in c['ub']:
            m=USEDIN.match(rest.split(' | ')[0].strip())
            if not m: continue
            a=m.group(1)
            if a==c['id'] or a not in cards: continue
            if (a,c['id']) in tog: continue
            covered=(a,c['id']) in cont or (c['id'],a) in cont
            fam=c['id'].startswith(a+'.')
            rev[(m21.PART[c['ch']],'continuation' if covered else 'NONE','own family' if fam else 'other')]+=1
            if not covered: rev_list.append((c['ch'],n,c['id'],a))
    res['TOGETHER links']=len(tog); res['forward missing']=len(fwd_missing); res['reverse']=dict(sorted(rev.items()))
    return res, fwd_missing, rev_list
if __name__=='__main__':
    b=v2lib.Build()
    res,f,r=run(b.lines)
    for k,v in res.items(): print(k,':',v)
    print('forward missing sample:',f[:5]); print('reverse not covered sample:',r[:8])
