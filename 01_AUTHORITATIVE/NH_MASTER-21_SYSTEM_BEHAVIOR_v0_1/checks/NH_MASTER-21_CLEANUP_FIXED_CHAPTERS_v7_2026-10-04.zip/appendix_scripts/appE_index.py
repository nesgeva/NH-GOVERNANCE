import sys; sys.path.insert(0,'/home/claude/m21/v6'); sys.path.insert(1,'/home/claude/m21/v2'); sys.path.insert(2,'/home/claude/m21/tools')
import m21, re, collections, v2check
CHS=[c for c in m21.CH if not c.startswith('CH12')]
KEYFILE={'V10':'01_AUTHORITATIVE/NH_MASTER-20_CORRECTED_v10.md','DD':'01_AUTHORITATIVE/NH_DECISION_DEFAULTS-S19_v2_2.md','CR':'01_AUTHORITATIVE/cursorrules',
 'COMP':'01_AUTHORITATIVE/NH_PROJECT_COMPANION_GOVERNANCE_AND_ARCHIVE_v1.md','MAP':'02_WORKING_MAP/NH_COMPLETE_DESIGN_AND_WIRING_MAP_v1_6_CANDIDATE.md','DR':'05_ACTIVE_CANDIDATE/NH_DECISION_RECORD_PRE_V10_RECOVERY_2026-09-24_v0_1_CANDIDATE.md'}
PRE={'04/':'04_ACCEPTED_STANDALONE_DESIGNS/','05/':'05_ACTIVE_CANDIDATE/','05i/':'05_INACTIVE_CANDIDATE/','98/':'98_HISTORICAL_SOURCES_PRE_V10/'}
def file_of(c):
    c=c.strip('[]')
    for k,v in KEYFILE.items():
        if c==k or c.startswith(k+' '): return v
    for k,v in PRE.items():
        if c.startswith(k): return v+re.split(r' §| FR-| /',c[len(k):])[0].strip()
    return None
def natkey(i):
    return [(0,int(p)) if p.isdigit() else (1,p) for p in re.split(r'[-.]',i)]
def index(get):
    cards=v2check.parse(get); own={}
    for c in cards.values():
        last=max([c['start']]+[x[0] for x in c['boxes']]+[u[0] for u in c['ub']])
        for n in range(c['start'],last+1): own[(c['ch'],n)]=c['id']
    occ=collections.defaultdict(list)   # citation string -> [(ch,n,owner)]
    for ch in CHS:
        for n,s in enumerate(get(ch),1):
            for c in re.findall(r'\[[^\[\]]+\]',s):
                if re.match(r'\[(V10|DD|CR|COMP|MAP|DR|04/|05/|05i/|98/)',c): occ[c].append((ch,n,own.get((ch,n))))
    return occ, cards
def ranges(locs):
    by=collections.OrderedDict()
    for ch,n,_ in sorted(set(locs), key=lambda x:(CHS.index(x[0]),x[1])): by.setdefault(ch,[]).append(n)
    return '; '.join(f'{ch}:{ns[0]}–{ns[-1]} ({len(set(ns))} lines)' if ns[0]!=ns[-1] else f'{ch}:{ns[0]} (1 lines)' for ch,ns in by.items())
