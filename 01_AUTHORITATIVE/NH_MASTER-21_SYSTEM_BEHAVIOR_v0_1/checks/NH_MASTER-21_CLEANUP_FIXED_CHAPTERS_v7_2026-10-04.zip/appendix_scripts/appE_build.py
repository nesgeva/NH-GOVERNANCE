import sys; sys.path.insert(0,'/home/claude/m21/v6'); sys.path.insert(1,'/home/claude/m21/v2'); sys.path.insert(2,'/home/claude/m21/tools')
import v6lib as v2lib, m21, re, collections, json, v2check
from appE_index import file_of, natkey, ranges, CHS
b=v2lib.Build()
def cells(s): return [x.strip() for x in re.split(r'(?<!\\)\|',s.strip())[1:-1]]
cards=v2check.parse(b.lines); IDS=set(cards)
own={}
for c in cards.values():
    last=max([c['start']]+[x[0] for x in c['boxes']]+[u[0] for u in c['ub']])
    for n in range(c['start'],last+1): own[(c['ch'],n)]=('card',c['id'])
PATHIDS=set()
for ch in ('CH00','CH11'):
    L=b.lines(ch); cur=None
    for n,s in enumerate(L,1):
        m=re.match(r'^## ((?:P|CY)-[A-Za-z\-]+) — ',s)
        if m: cur=m.group(1); PATHIDS.add(cur); continue
        if s.startswith('## ') or s.startswith('### '): cur=None if s.startswith('## ') else cur
        if cur and (ch,n) not in own: own[(ch,n)]=('path',cur)
ALLIDS=IDS|PATHIDS
IDRE=re.compile(r'(?<![\w.\-])((?:C|P|CY)-[A-Za-z0-9][A-Za-z0-9\-]*(?:\.[0-9A-Za-z]+)*)')
contsec={}
for ch in CHS:
    head=''
    for n,s in enumerate(b.lines(ch),1):
        if s.startswith('#'): head=s
        if (ch,n) not in own and s.startswith('| ') and 'continuation' in head.lower():
            ids=[x for x in IDRE.findall(s) if x in ALLIDS]
            if ids: own[(ch,n)]=('cont',tuple(dict.fromkeys(ids)))
occ=collections.defaultdict(list)
for ch in CHS:
    for n,s in enumerate(b.lines(ch),1):
        for c in re.findall(r'\[[^\[\]]+\]',s):
            if re.match(r'\[(V10|DD|CR|COMP|MAP|DR|04/|05/|05i/|98/)',c): occ[c].append((ch,n,own.get((ch,n))))
def owners_of(locs):
    o=set()
    for (ch,n,w) in locs:
        if not w: continue
        if w[0] in ('card','path'): o.add(w[1])
        else: o.update(w[1])
    return sorted(o,key=natkey)
byfile=collections.defaultdict(list)
for c,ls in occ.items():
    f=file_of(c)
    if f: byfile[f].extend(ls)
json.dump({'occ':{k:v for k,v in occ.items()},'byfile':byfile},open('appE_occ.json','w'))
L=b.lines('CH12-e')
def table(tag):
    i=L.index(f'<!-- BEGIN DATA E {tag} -->'); j=L.index(f'<!-- END DATA E {tag} -->'); return i,j,[cells(s) for s in L[i+3:j]]
def cov_evidence(path):
    locs=[]
    for ch in CHS:
        for n,s in enumerate(b.lines(ch),1):
            if f'`{path}`' in s and (ch,n) not in own: locs.append((ch,n,None))
    return ranges(locs) if locs else 'No coverage-table row names this file.'
out={}
esc=lambda x: x.replace('|','\\|')
for tag in ('FILES','EXTRA'):
    i,j,R=table(tag); new=[]; st=collections.Counter()
    for k in R:
        fn=k[0].strip('`'); ls=byfile.get(fn,[]); ow=owners_of(ls)
        place=k[2]
        if place.startswith('Cited owners:') or (tag=='EXTRA'):
            if ow: place=('Cited owners: ' if tag=='FILES' else '')+', '.join(f'`{x}`' for x in ow); st['owners']+=1
            else: place='NOT PLACED: no canonical part or path in the finished chapters cites this file.' if tag=='FILES' else 'NOT PLACED'; st['now unplaced']+=1
        else: st['kept: '+place.split(':')[0][:20]]+=1
        ev=ranges(ls) if ls else 'No matching source locator.'
        if tag=='FILES': new.append(f'| {k[0]} | {k[1]} | {esc(place)} | {ev} | {cov_evidence(fn)} |')
        else: new.append(f'| {k[0]} | {k[1]} | {esc(place)} | {ev} |')
    out[tag]=new; print(tag,len(new),dict(st))
i,j,R=table('ANCHORS'); new=[]
for k in R:
    a=k[0]; ls=occ.get(a,[]); ow=owners_of(ls)
    new.append(f'| {a} | {", ".join(f"`{x}`" for x in ow) if ow else "No canonical owner"} | {ranges(ls) if ls else "No matching source locator."} |')
out['ANCHORS']=new; print('ANCHORS',len(new),'with no occurrence:',sum(1 for k in R if not occ.get(k[0])))
json.dump(out,open('appE_tables1.json','w'),ensure_ascii=False)
print('sample FILES row:',out['FILES'][5][:400])
