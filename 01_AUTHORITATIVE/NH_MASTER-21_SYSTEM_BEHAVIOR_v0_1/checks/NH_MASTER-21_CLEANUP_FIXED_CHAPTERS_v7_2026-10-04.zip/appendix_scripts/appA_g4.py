import sys; sys.path.insert(0,'/home/claude/m21/v6'); sys.path.insert(1,'/home/claude/m21/v2'); sys.path.insert(2,'/home/claude/m21/tools')
import v6lib as v2lib, m21, re, collections, json, v2check
b=v2lib.Build()
def cells(s): return [x.strip() for x in re.split(r'(?<!\\)\|',s.strip())[1:-1]]
cards=v2check.parse(b.lines)
CHS=[c for c in m21.CH if not c.startswith('CH12')]
inc={ch:set() for ch in CHS}
for c in cards.values():
    if c['ch'] in inc:
        last=max([c['start']]+[x[0] for x in c['boxes']]+[u[0] for u in c['ub']]); inc[c['ch']].update(range(c['start'],last+1))
BOXES=('What it is','Takes in','Does','Gives out','Must never','Fails closed by','Fed by','Gated by','Changes')
old=[cells(s) for s in b.lines('CH12-a') if re.match(r'^\| \d+ \| CH\d',s)]
G4=[k for k in old if not (k[2].startswith('C-') and (k[3] in BOXES or re.match(r'^USED BY \d+ / (Takes in|Does|Changes) there / ',k[3]) and ' cell ' in k[1] and int(re.search(r'cell (\d+)',k[1]).group(1))<=5 and not re.match(r'^USED BY \d{4,}',k[3])))]
print('non-card entries to re-find:',len(G4))
res=collections.Counter(); out=[]; un=[]
for k in G4:
    num,loc,part,field,val,named=k[:6]
    ch=loc.split(':')[0]; cellno=re.search(r'cell (\d+)',loc); cellno=int(cellno.group(1)) if cellno else None
    L=b.lines(ch); val2=val.replace('\\|','|'); fld=field.replace('\\|','|')
    pid=re.match(r'^((?:C|P|CY)-[A-Za-z0-9][A-Za-z0-9\-]*(?:\.[0-9A-Za-z]+)*)',part); pid=pid.group(1) if pid else None
    cand=[]
    for n,s in enumerate(L,1):
        if n in inc[ch] or 'NOT DECIDED' not in s: continue
        if val2!='NOT DECIDED' and val2 in s: cand.append(n); continue
        if val2=='NOT DECIDED':
            if fld and fld in s and (pid is None or pid in s): cand.append(n)
            elif pid and re.search(r'(?<![\w.\-])'+re.escape(pid)+r'(?![\w.\-]|\.\d)',s) and re.match(r'^(Whole-path stamp|Stamp|Trigger|Exit|Step \d+)$',fld): cand.append(n)
    if len(cand)==1: res['found']+=1; out.append((k,ch,cand[0],cellno))
    elif not cand: res['not found']+=1; un.append(('none',k))
    else: res['several']+=1; un.append(('several',k,cand))
print(dict(res))
json.dump({'found':out,'un':un},open('appA_g4.json','w'),ensure_ascii=False)
for u in un[:14]: print(u[0],'|'.join(u[1][1:5])[:150], u[2] if len(u)>2 else '')
