import sys; sys.path.insert(0,'/home/claude/m21/v6'); sys.path.insert(1,'/home/claude/m21/v2'); sys.path.insert(2,'/home/claude/m21/tools')
import v6lib as v2lib, m21, re, collections, json, v2check
b=v2lib.Build()
def cells(s): return [x.strip() for x in re.split(r'(?<!\\)\|',s.strip())[1:-1]]
CHS=[c for c in m21.CH if not c.startswith('CH12')]
cards=v2check.parse(b.lines)
BOXES=('What it is','Takes in','Does','Gives out','Must never','Fails closed by','Fed by','Gated by','Changes')
CELLN={3:'Takes in there',4:'Does there',5:'Changes there'}
inc={ch:set() for ch in CHS}
for c in cards.values():
    if c['ch'] not in inc: continue
    last=max([c['start']]+[x[0] for x in c['boxes']]+[u[0] for u in c['ub']]); inc[c['ch']].update(range(c['start'],last+1))
# register rows: (ch, part, normalized field) -> [(line, extra text)]
REG=collections.defaultdict(list)
def normf(f):
    f=re.sub(r'^(?:ALONE|TOGETHER) / ','',f); f=re.sub(r'^USED BY (?:row )?(\d+) / ',r'USED BY \1 / ',f); return f
for ch in CHS:
    for n,s in enumerate(b.lines(ch),1):
        if n in inc[ch] or not s.startswith('| '): continue
        k=cells(s)
        if len(k)<2: continue
        m=re.match(r'^`?((?:C|P|CY)-[A-Za-z0-9][A-Za-z0-9\-]*(?:\.[0-9A-Za-z]+)*)`?(?: — .*)?$',k[0]) or re.match(r'^[\d\.]+ / ((?:P|CY)-[A-Z]+)$',k[0])
        if not m: continue
        extra=[x for x in k[2:] if x and x!='NOT DECIDED' and not re.fullmatch(r'\d+',x)]
        REG[(ch,m.group(1),normf(k[1]))].append((n,' '.join(extra)))
def reg_for(ch,part,field):
    r=REG.get((ch,part,normf(field)))
    if not r: return None,''
    return r[0][0], r[0][1]
E=[]  # (ch, line, cellno, part, field, value, named)
miss_reg=collections.Counter()
for c in sorted(cards.values(), key=lambda c:(CHS.index(c['ch']) if c['ch'] in CHS else 99, c['start'])):
    ch=c['ch']
    if ch not in CHS: continue
    for (n,bx,t) in c['boxes']:
        if t.strip()=='NOT DECIDED':
            rl,why=reg_for(ch,c['id'],bx)
            if rl is None: miss_reg['box']+=1
            E.append((ch,n,None,c['id'],bx,'NOT DECIDED',(why+' ' if why else '')+(f'Register: {ch}:{rl}' if rl else '')))
    if c['ub'] and all(u[3].split(' | ')[0].strip()=='NOT DECIDED' for u in c['ub']):
        rl,why=reg_for(ch,c['id'],'USED BY')
        if rl is None: miss_reg['whole USED BY table']+=1
        E.append((ch,c['ub'][0][0],None,c['id'],'USED BY','NOT DECIDED (no use row is decided)',(why+' ' if why else '')+(f'Register: {ch}:{rl}' if rl else '')))
    else:
        for (n,num,st,rest) in c['ub']:
            k=[x.strip() for x in rest.rstrip().rstrip('|').split(' | ')]
            for ci,name in CELLN.items():
                v=k[ci-2] if len(k)>ci-2 else ''
                if 'NOT DECIDED' in v:
                    f=f'USED BY {num} / {name}'
                    rl,why=reg_for(ch,c['id'],f)
                    if rl is None: miss_reg['use cell']+=1
                    E.append((ch,n,ci,c['id'],f+' / '+k[0],v,(why+' ' if why else '')+(f'Register: {ch}:{rl}' if rl else '')))
print('card-local entries:',len(E),' by kind:',dict(collections.Counter('box' if e[4] in BOXES else ('table' if e[4]=='USED BY' else 'cell') for e in E)),' without a register row:',dict(miss_reg))
json.dump(E,open('appA_cardlocal.json','w'),ensure_ascii=False)
