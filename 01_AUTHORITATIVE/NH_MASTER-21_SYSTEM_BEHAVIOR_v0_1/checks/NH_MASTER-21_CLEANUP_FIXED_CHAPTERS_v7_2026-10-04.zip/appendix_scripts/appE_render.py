import sys; sys.path.insert(0,'/home/claude/m21/v6'); sys.path.insert(1,'/home/claude/m21/v2'); sys.path.insert(2,'/home/claude/m21/tools')
import v6lib as v2lib, m21, re, collections, json, hashlib
from appRefresh import refresh
from appE_index import CHS
b=v2lib.Build()
L=b.lines('CH12-e')
T1=json.load(open('appE_tables1.json')); T2=json.load(open('appE_tables2.json')); V=json.load(open('appE_v10rows.json'))
esc=lambda x: x.replace('|','\\|')
Vrows=[f'| {r[0]} | {esc(r[1])} | {esc(r[2])} | {esc(r[3])} |' for r in V]
def put(L,tag,rows):
    i=L.index(f'<!-- BEGIN DATA E {tag} -->'); j=L.index(f'<!-- END DATA E {tag} -->'); return L[:i+3]+rows+L[j:]
for tag,rows in (('FILES',T1['FILES']),('V10',Vrows),('ANCHORS',T1['ANCHORS']),('EXTRA',T1['EXTRA']),('CONTINUATIONS',T2['CONT']),('CH00',T2['CH00'])): L=put(L,tag,rows)
L=refresh(b,L)
def cells(s): return [x.strip() for x in re.split(r'(?<!\\)\|',s.strip())[1:-1]]
fk=collections.Counter()
for s in T1['FILES']:
    p=cells(s)[2]
    if p.startswith('Cited owners:'): fk['cited']+=1
    elif p.startswith('Coverage-declared'): fk['declared_only']+=1
    elif p.startswith('EXCLUDED'): fk['excluded']+=1
    elif p.startswith('NOT PLACED as part/path behavi'):
        fk['ledger' if 'LEDGER' in cells(s)[0].upper() else 'intent']+=1
    else: fk['not_placed']+=1
vk=collections.Counter('excluded' if r[2].startswith('EXCLUDED') else 'not_placed' if r[2].startswith('NOT PLACED') else 'placed' for r in V)
D=json.load(open('appE_occ.json')); occ=D['occ']
total=sum(len(v) for v in occ.values())
contlines=set()
for r in T2['CONT']:
    loc=cells(r)[0]; ch,a=loc.split(':'); a1,a2=[int(x) for x in a.split('–')]
    contlines.update((ch,n) for n in range(a1,a2+1))
contocc=sum(1 for v in occ.values() for (ch,n,w) in v if (ch,n) in contlines)
vals={'Input chapter files':61,'Preserved input hashes':61,'Canonical part cards':9392,'Canonical path definitions':26,'READ-file rows':len(T1['FILES']),'V10 heading rows':len(V),
 'READ files — cited':fk['cited'],'READ files — declared_only':fk['declared_only'],'READ files — excluded':fk['excluded'],'READ files — intent':fk['intent'],'READ files — ledger':fk['ledger'],'READ files — not_placed':fk['not_placed'],
 'V10 headings — excluded':vk['excluded'],'V10 headings — not_placed':vk['not_placed'],'V10 headings — placed':vk['placed'],'Additional exact V10 citation anchors':len(T1['ANCHORS']),'Existing out-of-folder cited files':len(T1['EXTRA']),
 'Extracted source-citation occurrences':total,'Continuation citation occurrences':contocc,'Continuation sections':len(T2['CONT']),'Continuation nonempty lines':sum(int(cells(r)[2]) for r in T2['CONT']),'CH00 naming/path exact rows':len(T2['CH00'])}
out=[]
for s in L:
    k=cells(s)[0] if s.startswith('| ') else None
    out.append(f'| {k} | {vals[k]} |' if k in vals else s)
L=out
# exceptions: reasoned NOT PLACED V10 headings and READ files
x=L.index('### Named extraction exceptions'); e0=x+4; e1=e0
while e1<len(L) and L[e1].startswith('|'): e1+=1
old={cells(s)[0]:cells(s)[1] for s in L[e0:e1]}
ex=[]
for r in V:
    if r[2].startswith('NOT PLACED'):
        key=f'V10:{r[0]} — {r[1]}'
        ex.append(f'| {esc(key)} | '+(old.get(key) or 'No heading-specific placement evidence; recorded as reasoned NOT PLACED, not a new decision or an extraction omission.')+' |')
for s in T1['FILES']:
    k=cells(s)
    if k[2].startswith('NOT PLACED') and not k[2].startswith('NOT PLACED as part/path behavi'):
        fn=k[0].strip('`'); ex.append(f'| {fn} | '+(old.get(fn) or 'No canonical part or path in the finished chapters cites this exact file; the file remains reasoned NOT PLACED. This is not a claim that its matching design package is unplaced.')+' |')
L=L[:e0]+ex+L[e1:]
L=[(f'| Named extraction exceptions | {len(ex)} |' if s.startswith('| Named extraction exceptions |') else s) for s in L]
json.dump(L,open('CH12-e_v2_lines.json','w'),ensure_ascii=False)
print(vals); print('exceptions:',len(ex),' lines:',len(L))
