import sys; sys.path.insert(0,'/home/claude/m21/v6'); sys.path.insert(1,'/home/claude/m21/v2'); sys.path.insert(2,'/home/claude/m21/tools')
import v6lib as v2lib, m21, re, collections, json, v2check
b=v2lib.Build()
def cells(s): return [x.strip() for x in re.split(r'(?<!\\)\|',s.strip())[1:-1]]
CHS=[c for c in m21.CH if not c.startswith('CH12')]
cards=v2check.parse(b.lines)
BOXES=('What it is','Takes in','Does','Gives out','Must never','Fails closed by','Fed by','Gated by','Changes')
inc={ch:set() for ch in CHS}
for c in cards.values():
    if c['ch'] in inc:
        last=max([c['start']]+[x[0] for x in c['boxes']]+[u[0] for u in c['ub']]); inc[c['ch']].update(range(c['start'],last+1))
def normf(f):
    f=re.sub(r'^(?:ALONE|TOGETHER) / ','',f); f=re.sub(r'^USED BY (?:row )?(\d+) / ',r'USED BY \1 / ',f); f=re.sub(r' / undecided remainder$','',f); return f
REG=collections.defaultdict(list)
for ch in CHS:
    for n,s in enumerate(b.lines(ch),1):
        if n in inc[ch] or not s.startswith('| '): continue
        k=cells(s)
        if len(k)<2: continue
        m=re.match(r'^`?((?:C|P|CY)-[A-Za-z0-9][A-Za-z0-9\-]*(?:\.[0-9A-Za-z]+)*)`?(?: — .*)?$',k[0])
        if not m: continue
        extra=[x for x in k[2:] if x and x!='NOT DECIDED' and not re.fullmatch(r'\d+',x)]
        REG[(ch,m.group(1),normf(k[1]))].append((n,' '.join(extra)))
def regtext(ch,part,field):
    r=REG.get((ch,part,normf(field)),[])
    why=next((w for _,w in r if w),'')
    refs='; '.join(f'{ch}:{n}' for n,_ in r)
    return ((why+' ') if why else '')+(f'Register: {refs}' if refs else '')
E=[]
for c in sorted(cards.values(), key=lambda c:(CHS.index(c['ch']) if c['ch'] in CHS else 99, c['start'])):
    ch=c['ch']
    if ch not in CHS: continue
    for (n,bx,t) in c['boxes']:
        if 'NOT DECIDED' in t:
            E.append((ch,n,None,c['id'],bx,'NOT DECIDED' if t.strip()=='NOT DECIDED' else t.strip(),regtext(ch,c['id'],bx)))
    if c['ub'] and all(u[3].split(' | ')[0].strip()=='NOT DECIDED' for u in c['ub']):
        E.append((ch,c['ub'][0][0],None,c['id'],'USED BY','NOT DECIDED (no use row is decided)',regtext(ch,c['id'],'USED BY')))
    else:
        for (n,num,st,rest) in c['ub']:
            k=[x.strip() for x in rest.rstrip().rstrip('|').split(' | ')]
            for ci,name in ((3,'Takes in there'),(4,'Does there'),(5,'Changes there')):
                v=k[ci-2] if len(k)>ci-2 else ''
                if 'NOT DECIDED' in v:
                    E.append((ch,n,ci,c['id'],f'USED BY {num} / {name} / {k[0]}',v,regtext(ch,c['id'],f'USED BY {num} / {name}')))
# non-card entries from the re-find, with CH00 registers mapped explicitly
A=[tuple(e) for e in json.load(open('appA_all.json'))['all'] if not (e[3].startswith('C-') and (e[4] in BOXES or e[4].startswith('USED BY') or e[4]=='USED BY'))]
CH00REG={('P-MAIN','Whole-path stamp'):557,('P-MAIN','Step 17'):558,('P-MAIN','Exit'):559,('P-MAIN','Stamp'):560}
for p,n in (('CY-B',561),('CY-C',562),('CY-D',563),('CY-E',564),('CY-F',565),('CY-G',566),('CY-H',567),('CY-I',568),('CY-J',569)): CH00REG[(p,'Stamp')]=n
CH00REG[('CY-G','Trigger')]=570; CH00REG[('CY-J','Trigger')]=571
L00=b.lines('CH00')
for i,e in enumerate(A):
    if e[0]=='CH00' and (e[3],e[4]) in CH00REG:
        r=CH00REG[(e[3],e[4])]; assert e[3].split('-')[-1] in L00[r-1] or e[3] in L00[r-1],(e,L00[r-1])
        A[i]=e[:6]+(re.sub(r'Register: [^|]*$',f'Register: CH00:{r}',e[6]) if 'Register:' in e[6] else e[6],)
# CH03-a: the unlisted 'Additional unresolved detail' row and the 11 continuation cells
L3=b.lines('CH03-a')
rn=[k+1 for k,x in enumerate(L3) if x.startswith('| Root identity generation scheme | C-STORE.4.7.3 | NOT DECIDED |')]; assert len(rn)==1
if ('CH03-a',rn[0]) not in set((e[0],e[1]) for e in A): A.append(('CH03-a',rn[0],1,'C-STORE.4.7.3','Root identity generation scheme','NOT DECIDED',''))
Lb=b.lines('CH03-b'); og=[k+1 for k,x in enumerate(Lb) if x.startswith('|') and 'owner NOT DECIDED' in x and 'Group 5' in x]
for r in og:
    if ('CH03-b',r,2) not in set((e[0],e[1],e[2]) for e in A):
        cl=[y.strip() for y in Lb[r-1].strip().strip('|').split(' | ')]
        A.append(('CH03-b',r,2,'No part/path ID supplied; '+cl[0],'Owner of the remaining restored Group 5 requirements',cl[1],''))
cont=[]
for n,s in enumerate(L3,1):
    if n in inc['CH03-a'] or not re.match(r'^\| C-[^|]+ — [^|]+ \| (ACCEPTED|DESIGNED|CANDIDATE|BUILT|DECIDED-[\d\-]+|INTENT) \| C-',s): continue
    k=cells(s)
    for ci,name in ((4,'Takes in there'),(5,'Does there'),(6,'Changes there')):
        if len(k)>=ci and k[ci-1]=='NOT DECIDED':
            pid=re.match(r'^(C-\S+) — ',k[0]).group(1); ui=k[2]
            cont.append((n,ci,pid,name,ui))
have=set((e[0],e[1],e[2]) for e in A)
newcont=[c for c in cont if ('CH03-a',c[0],c[1]) not in have]
print('continuation cells in CH03-a:',len(cont),' already listed:',len(cont)-len(newcont),' new:',len(newcont))
json.dump(newcont,open('appA_newcont.json','w'))
for (n,ci,pid,name,ui) in newcont:
    uid=re.match(r'^(C-\S+)',ui).group(1)
    rr=[k+1 for k,x in enumerate(L3) if x.startswith(f'| {pid} | Continuation USED BY {uid} / {name} |')]
    A.append(('CH03-a',n,ci,pid,f'Continuation USED BY / {name} / {ui}','NOT DECIDED','Register: '+'; '.join(f'CH03-a:{r}' for r in rr) if rr else 'REGISTER-PENDING'))
ALL=E+A
order={c:i for i,c in enumerate(CHS)}
ALL.sort(key=lambda e:(order[e[0]],e[1],e[2] or 0))
dup=[k for k,v in collections.Counter((e[0],e[1],e[2]) for e in ALL).items() if v>1]
print('entries:',len(ALL),' duplicate locations:',len(dup),dup[:4])
print('entries without a register line:',sum(1 for e in ALL if 'Register:' not in (e[6] or '') and e[6]!='REGISTER-PENDING'))
json.dump(ALL,open('appA_final.json','w'),ensure_ascii=False)
