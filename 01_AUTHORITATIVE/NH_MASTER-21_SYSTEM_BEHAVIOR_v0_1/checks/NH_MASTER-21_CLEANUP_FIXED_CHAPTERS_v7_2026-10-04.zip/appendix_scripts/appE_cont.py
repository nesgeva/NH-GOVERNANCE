import sys; sys.path.insert(0,'/home/claude/m21/v6'); sys.path.insert(1,'/home/claude/m21/v2'); sys.path.insert(2,'/home/claude/m21/tools')
import v6lib as v2lib, m21, re, collections, json, v2check
from appE_index import natkey, CHS
b=v2lib.Build()
def cells(s): return [x.strip() for x in re.split(r'(?<!\\)\|',s.strip())[1:-1]]
cards=v2check.parse(b.lines); IDS=set(cards)
IDRE=re.compile(r'(?<![\w.\-])((?:C|P|CY)-[A-Za-z0-9][A-Za-z0-9\-]*(?:\.[0-9A-Za-z]+)*)')
PATHS={'P-MAIN','CY-A','CY-B','CY-C','CY-D','CY-E','CY-F','CY-G','CY-H','CY-I','CY-J'}|{m.group(1) for s in b.lines('CH11') for m in [re.match(r'^## (P-NEW-[a-z]+) — ',s)] if m}
L=b.lines('CH12-e'); i=L.index('<!-- BEGIN DATA E CONTINUATIONS -->'); j=L.index('<!-- END DATA E CONTINUATIONS -->')
R=[cells(s) for s in L[i+3:j]]
def sections(ch):
    LL=b.lines(ch); hs=[n for n,s in enumerate(LL,1) if s.startswith('#')]+[len(LL)+1]
    out=[]
    for k,a in enumerate(hs[:-1]):
        z=hs[k+1]
        body=[n for n in range(a+1,z) if LL[n-1].strip()] or [a]
        out.append((a,LL[a-1],body))
    return out
used=collections.defaultdict(int); out=[]; miss=[]
for k in R:
    ch=k[0].split(':')[0]; head=k[1]
    secs=[s for s in sections(ch) if re.sub(r'^#+\s*','',s[1]).strip()==head]
    k_ord=used[(ch,head)]; used[(ch,head)]+=1
    if k_ord>=len(secs): miss.append((ch,head)); continue
    a,hl,body=secs[k_ord]
    if not body: miss.append((ch,head,'empty')); continue
    LL=b.lines(ch); ids=set()
    for n in body: ids.update(x for x in IDRE.findall(LL[n-1]) if x in IDS or x in PATHS)
    out.append(f'| {ch}:{body[0]}–{body[-1]} | {head} | {len(body)} | {", ".join(f"`{x}`" for x in sorted(ids,key=natkey))} |')
# sections with 'continuation' in the heading that the old index did not list
listed=set((o.split('|')[1].strip().split(':')[0],o.split('|')[2].strip()) for o in out)
extra=[(ch,a,re.sub(r'^#+\s*','',h).strip(),body) for ch in CHS for (a,h,body) in sections(ch) if 'continuation' in h.lower() and not re.match(r'^#+ C-',h) and (ch,re.sub(r'^#+\s*','',h).strip()) not in listed and body]
for (ch,a,head,body) in extra:
    LL=b.lines(ch); ids=set()
    for n in body: ids.update(x for x in IDRE.findall(LL[n-1]) if x in IDS or x in PATHS)
    out.append(f'| {ch}:{body[0]}–{body[-1]} | {head} | {len(body)} | {", ".join(f"`{x}`" for x in sorted(ids,key=natkey))} |')
out.sort(key=lambda r:(CHS.index(r.split('|')[1].strip().split(':')[0]),int(re.match(r'\S+:(\d+)',r.split('|')[1].strip()).group(1))))
print('continuation rows:',len(out),' not found:',len(miss),miss[:5],' added (unlisted before):',len(extra),[(e[0],e[2]) for e in extra][:8])
# CH00 table
i=L.index('<!-- BEGIN DATA E CH00 -->'); j=L.index('<!-- END DATA E CH00 -->')
C=[cells(s) for s in L[i+3:j]]; out0=[]; m0=[]
esc=lambda x: x.replace('|','\\|')
for k in C:
    ch=k[0].split(':')[0]; row=k[1].replace('\\|','|')
    hits=[n for n,s in enumerate(b.lines(ch),1) if s==row]
    if len(hits)!=1:
        key=cells(row)[:2]; hits=[n for n,s in enumerate(b.lines(ch),1) if s.startswith('|') and cells(s)[:2]==key]
    if len(hits)!=1: m0.append((k[0],row[:60],hits[:3])); continue
    out0.append(f'| {ch}:{hits[0]} | {esc(b.lines(ch)[hits[0]-1])} |')
print('CH00 rows rebuilt:',len(out0),' not found:',m0)
json.dump({'CONT':out,'CH00':out0,'miss':miss,'extra':extra},open('appE_tables2.json','w'),ensure_ascii=False)
print(out[0][:200]); print(out[1][:200])
