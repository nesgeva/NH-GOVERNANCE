"""Master-21 cleanup round toolkit (Claude, 2026-10-04).
Read-only helpers for verifying checker findings against:
  - v1  : the cleanup round v1 chapters (after)
  - kit : the 66 chapters before the cleanup round
  - pin : nesgeva/NH-GOVERNANCE at 6a7160ba688ba4e433a31899162815df7e2bab17
Nothing here writes to any chapter.
"""
import json, re, os, hashlib, functools, collections

ROOT = '/home/claude/m21'
PIN = '/home/claude/pin'
PRE = 'NH_MASTER-21_SYSTEM_BEHAVIOR_v0_1_CANDIDATE__'
CH = ['CH00','CH01','CH02'] + ['CH03-'+c for c in 'abcdefghijklmnop'] + \
     ['CH04-'+c for c in 'abcde'] + ['CH05-'+c for c in 'abcde'] + \
     ['CH06-'+c for c in 'abcdefg'] + ['CH07-'+c for c in 'abc'] + \
     ['CH08-'+c for c in 'abcdefg'] + ['CH09-'+c for c in 'abcdefghi'] + \
     ['CH10-'+c for c in 'abcde'] + ['CH11'] + ['CH12-'+c for c in 'abcde']
assert len(CH) == 66
PART = {}
for c in CH:
    n = int(c[2:4])
    PART[c] = 'A' if n <= 3 else ('B' if n <= 8 else 'C')

def path(ch, side='v1'):
    return f'{ROOT}/{side}/{PRE}{ch}.md'

@functools.lru_cache(maxsize=None)
def lines(ch, side='v1'):
    with open(path(ch, side), encoding='utf-8') as f:
        return f.read().split('\n')

def L(ch, n, side='v1'):
    """1-based line."""
    ls = lines(ch, side)
    return ls[n-1] if 1 <= n <= len(ls) else None

def show(ch, n, side='v1', ctx=2, width=600):
    ls = lines(ch, side)
    for i in range(max(1, n-ctx), min(len(ls), n+ctx)+1):
        mark = '>>' if i == n else '  '
        print(f'{mark}{side}:{ch}:{i}: {ls[i-1][:width]}')

def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()

# ---------------- record ----------------
@functools.lru_cache(maxsize=None)
def record():
    return json.load(open(f'{ROOT}/v1/NH_MASTER-21_CLEANUP_RECORD_v1_2026-10-03.json', encoding='utf-8'))

@functools.lru_cache(maxsize=None)
def items():
    return {it['id']: it for it in record()['items']}

def item(i):
    if isinstance(i, int):
        i = f'R5-{i:05d}'
    return items().get(i)

@functools.lru_cache(maxsize=None)
def items_by_loc():
    d = collections.defaultdict(list)
    for it in record()['items']:
        d[(it['chapter'], it['line'])].append(it)
    return d

def pitem(i, width=900):
    it = item(i)
    if not it:
        print('NO ITEM', i); return
    for k, v in it.items():
        s = json.dumps(v, ensure_ascii=False) if not isinstance(v, str) else v
        print(f'  {k}: {s[:width]}')

# ---------------- diff before/after ----------------
@functools.lru_cache(maxsize=None)
def opcodes(ch):
    import difflib
    a, b = lines(ch, 'kit'), lines(ch, 'v1')
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    return [op for op in sm.get_opcodes() if op[0] != 'equal']

def after_to_before(ch, n):
    """map after line n to before line (None if inserted)."""
    import difflib
    a, b = lines(ch, 'kit'), lines(ch, 'v1')
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if j1 <= n-1 < j2:
            if tag == 'equal':
                return i1 + (n-1-j1) + 1
            return None
    return None

# ---------------- card parser ----------------
CARD_RE = re.compile(r'^### (C-[A-Za-z0-9][A-Za-z0-9\-]*(?:\.[0-9A-Za-z]+)*) — (.*)$')
BOX_RE = re.compile(r'^- (What it is|Takes in|Does|Gives out|Must never|Fails closed by|Fed by|Gated by|Changes):\s?(.*)$')
BOXES = ['What it is','Takes in','Does','Gives out','Must never','Fails closed by','Fed by','Gated by','Changes']
UB_ROW_RE = re.compile(r'^\| (\d+) · ([A-Z0-9\-]+(?: [A-Z]+)?) \| (.*)$')
STAMPS = ['BUILT','DESIGNED','ACCEPTED','CANDIDATE','INTENT','DECIDED-2026-09-24','DECIDED-2026-09-25','NOT DECIDED']
ID_AT_START_RE = re.compile(r'^(C-[A-Za-z0-9][A-Za-z0-9\-]*(?:\.[0-9A-Za-z]+)*) — ')

class Card:
    __slots__ = ('id','title','ch','start','end','stamp_line','boxes','ub','sub','ub_header')
    def __repr__(self):
        return f'<Card {self.id} {self.ch}:{self.start}-{self.end}>'

@functools.lru_cache(maxsize=None)
def cards(ch, side='v1'):
    ls = lines(ch, side)
    out = []
    cur = None
    in_behavior = True
    for i, s in enumerate(ls, 1):
        m = CARD_RE.match(s)
        if m:
            if cur: cur.end = i-1; out.append(cur)
            cur = Card(); cur.id, cur.title, cur.ch, cur.start = m.group(1), m.group(2), ch, i
            cur.stamp_line = None; cur.boxes = []; cur.ub = []; cur.sub = None; cur.ub_header = None; cur.end = None
            continue
        if cur is None:
            continue
        if s.startswith('## ') or s.startswith('<!-- END'):
            cur.end = i-1; out.append(cur); cur = None; continue
        if s.startswith('Stamp:') and cur.stamp_line is None:
            cur.stamp_line = i
        bm = BOX_RE.match(s)
        if bm:
            cur.boxes.append((i, bm.group(1), bm.group(2)))
            continue
        if s.startswith('USED BY'):
            cur.ub_header = i
        um = UB_ROW_RE.match(s)
        if um and cur.ub_header:
            cur.ub.append((i, int(um.group(1)), um.group(2), um.group(3)))
            continue
        if s.startswith('SUB-PARTS:'):
            cur.sub = (i, s[len('SUB-PARTS:'):].strip())
    if cur:
        cur.end = len(ls); out.append(cur)
    return out

@functools.lru_cache(maxsize=None)
def card_index(side='v1'):
    idx = {}
    dup = []
    for ch in CH:
        for c in cards(ch, side):
            if c.id in idx: dup.append((c.id, idx[c.id].ch, ch))
            idx[c.id] = c
    return idx, dup

def card(cid, side='v1'):
    return card_index(side)[0].get(cid)

def card_at(ch, n, side='v1'):
    for c in cards(ch, side):
        if c.start <= n <= (c.end or 10**9):
            return c
    return None

def split_stamp(text):
    """'BUILT — rest' -> ('BUILT','rest')"""
    for st in sorted(STAMPS, key=len, reverse=True):
        if text.startswith(st + ' — '):
            return st, text[len(st)+3:]
        if text == st:
            return st, ''
    return None, text

def ub_cells(rowtext):
    """rowtext is the part after '| n · STAMP | '. returns list of cells."""
    t = rowtext
    if t.endswith('|'): t = t[:-1]
    return [c.strip() for c in t.split(' | ')]

def named_id(text):
    m = ID_AT_START_RE.match(text)
    return m.group(1) if m else None

def official(cid, side='v1'):
    c = card(cid, side)
    return f'{c.id} — {c.title}' if c else None

# ---------------- citations ----------------
CITE_RE = re.compile(r'\[(V10|DD|CR|COMP|MAP|DR|04/|05/|05i/|98/|NHD-)([^\]]*)\]')

def cites(text):
    return re.findall(r'\[[^\[\]]+\]', text)

@functools.lru_cache(maxsize=None)
def pin_files():
    out = {}
    for dp, dn, fn in os.walk(PIN):
        if '.git' in dp: continue
        for f in fn:
            rel = os.path.relpath(os.path.join(dp, f), PIN)
            out.setdefault(f, []).append(rel)
    return out

def pin_path_for(cite):
    """Resolve a citation's file. Returns relative path or None."""
    c = cite.strip('[]')
    if c.startswith('V10'): return '01_AUTHORITATIVE/NH_MASTER-20_CORRECTED_v10.md'
    if c.startswith('DD'): return '01_AUTHORITATIVE/NH_DECISION_DEFAULTS-S19_v2_2.md'
    if c.startswith('CR'): return '01_AUTHORITATIVE/cursorrules'
    if c.startswith('COMP'): return '01_AUTHORITATIVE/NH_PROJECT_COMPANION_GOVERNANCE_AND_ARCHIVE_v1.md'
    if c.startswith('MAP'): return '02_WORKING_MAP/NH_COMPLETE_DESIGN_AND_WIRING_MAP_v1_6_CANDIDATE.md'
    for pre, folder in (('04/', '04_ACCEPTED_STANDALONE_DESIGNS/'), ('05/', '05_ACTIVE_CANDIDATE/'),
                        ('05i/', '05_INACTIVE_CANDIDATE/'), ('98/', '98_HISTORICAL_SOURCES_PRE_V10/')):
        if c.startswith(pre):
            rest = c[len(pre):]
            fname = rest.split(' §')[0].strip()
            p = folder + fname
            if os.path.exists(os.path.join(PIN, p)): return p
            hits = pin_files().get(os.path.basename(fname))
            return hits[0] if hits else None
    return None

@functools.lru_cache(maxsize=None)
def pin_text(rel):
    with open(os.path.join(PIN, rel), encoding='utf-8', errors='replace') as f:
        return f.read()

def pin_grep(rel, pattern, ctx=0, maxn=30, flags=re.I):
    t = pin_text(rel).split('\n')
    n = 0
    for i, s in enumerate(t, 1):
        if re.search(pattern, s, flags):
            for j in range(max(1, i-ctx), min(len(t), i+ctx)+1):
                print(f'{"*" if j==i else " "}{rel.split("/")[-1][:40]}:{j}: {t[j-1][:500]}')
            n += 1
            if n >= maxn: break
    return n

def headings(rel):
    return [(i, s) for i, s in enumerate(pin_text(rel).split('\n'), 1) if s.startswith('#')]

# ---------------- links ----------------
TOG = ('Fed by', 'Gated by', 'Changes')

@functools.lru_cache(maxsize=None)
def together_links(side='v1'):
    """list of (A_id, ch, line, box, stamp, B_id, text)"""
    out = []
    for ch in CH:
        for c in cards(ch, side):
            for (i, box, text) in c.boxes:
                if box not in TOG: continue
                st, rest = split_stamp(text)
                b = named_id(rest)
                if b:
                    out.append((c.id, ch, i, box, st, b, text))
    return out

@functools.lru_cache(maxsize=None)
def ub_rows(side='v1'):
    """list of (B_id, ch, line, num, stamp, A_id_or_None, usedin_cell, cells)"""
    out = []
    for ch in CH:
        for c in cards(ch, side):
            for (i, num, st, rest) in c.ub:
                cells = ub_cells(rest)
                usedin = cells[0] if cells else ''
                a = usedin_id(usedin)
                out.append((c.id, ch, i, num, st, a, usedin, cells))
    return out

USEDIN_ID_RE = re.compile(r'^(C-[A-Za-z0-9][A-Za-z0-9\-]*(?:\.[0-9A-Za-z]+)*)(?= — |,|;| |$)')
def usedin_id(cell):
    m = USEDIN_ID_RE.match(cell)
    return m.group(1) if m else None

ANY_ID_RE = re.compile(r'(C-[A-Za-z0-9][A-Za-z0-9\-]*(?:\.[0-9A-Za-z]+)*) — ')

@functools.lru_cache(maxsize=None)
def outside_card_rows(side='v1'):
    """Every table row outside card blocks: (ch, line, row, [ids in order])"""
    out = []
    for ch in CH:
        ls = lines(ch, side)
        inc = set()
        for c in cards(ch, side):
            inc.update(range(c.start, (c.end or c.start)+1))
        for i, s in enumerate(ls, 1):
            if i in inc or not s.startswith('| ') or s.startswith('|---'): continue
            ids = ANY_ID_RE.findall(s)
            if len(ids) >= 2:
                out.append((ch, i, s, ids))
    return out

@functools.lru_cache(maxsize=None)
def cont_pairs(side='v1'):
    """set of frozenset({X,Y}) for every outside-card row naming two card IDs."""
    s = collections.defaultdict(list)
    for ch, i, row, ids in outside_card_rows(side):
        for x in ids:
            for y in ids:
                if x != y:
                    s[(x, y)].append((ch, i))
    return s

def check_links(side='v1', chapters=None):
    idx, _ = card_index(side)
    ubset = collections.defaultdict(list)
    for (b, ch, i, num, st, a, usedin, cells) in ub_rows(side):
        if a: ubset[(b, a)].append((ch, i))
    togset = collections.defaultdict(list)
    for (a, ch, i, box, st, b, text) in together_links(side):
        togset[(a, b)].append((ch, i, box))
    cp = cont_pairs(side)
    fwd_missing = []   # TOGETHER link A->B without USED BY row on B for A
    for (a, ch, i, box, st, b, text) in together_links(side):
        if chapters and ch not in chapters: continue
        if b not in idx:
            fwd_missing.append(('NO_SUCH_CARD', a, ch, i, box, b)); continue
        if b == a: continue
        if not ubset.get((b, a)):
            fwd_missing.append(('NO_UB_ROW', a, ch, i, box, b, bool(cp.get((a, b)) or cp.get((b, a)))))
    rev_missing = []   # USED BY row on B naming A without TOGETHER line on A naming B
    for (b, ch, i, num, st, a, usedin, cells) in ub_rows(side):
        if chapters and ch not in chapters: continue
        if not a or a == b: continue
        if a not in idx:
            rev_missing.append(('NO_SUCH_CARD', b, ch, i, a)); continue
        if not togset.get((a, b)):
            rev_missing.append(('NO_TOG_LINE', b, ch, i, a, bool(cp.get((a, b)) or cp.get((b, a)))))
    return fwd_missing, rev_missing

# ---- multi-name TOGETHER parsing (every 'ID — Official title' in the line) ----
ANYID_RE = re.compile(r'(?<![A-Za-z0-9\.\-])(C-[A-Za-z0-9][A-Za-z0-9\-]*(?:\.[0-9A-Za-z]+)*) — ')
def names_in(text, side='v1'):
    idx, _ = card_index(side)
    out = []
    for m in ANYID_RE.finditer(text):
        cid = m.group(1)
        c = idx.get(cid)
        if c and text[m.end():].startswith(c.title):
            out.append(cid)
    return out

@functools.lru_cache(maxsize=None)
def together_links_all(side='v1'):
    out = []
    for ch in CH:
        for c in cards(ch, side):
            for (i, box, text) in c.boxes:
                if box not in TOG: continue
                st, rest = split_stamp(text)
                for b in names_in(rest, side):
                    out.append((c.id, ch, i, box, st, b, text))
    return out
