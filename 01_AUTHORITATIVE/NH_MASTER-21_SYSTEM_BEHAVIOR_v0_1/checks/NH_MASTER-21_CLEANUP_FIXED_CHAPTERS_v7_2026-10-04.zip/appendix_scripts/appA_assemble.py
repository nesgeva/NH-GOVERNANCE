import sys; sys.path.insert(0,'/home/claude/m21/v6'); sys.path.insert(1,'/home/claude/m21/v2'); sys.path.insert(2,'/home/claude/m21/tools')
import v6lib as v2lib, m21, re, collections, json, v2check
b=v2lib.Build()
def cells(s): return [x.strip() for x in re.split(r'(?<!\\)\|',s.strip())[1:-1]]
CHS=[c for c in m21.CH if not c.startswith('CH12')]
cards=v2check.parse(b.lines)
inc={ch:set() for ch in CHS}
for c in cards.values():
    if c['ch'] in inc:
        last=max([c['start']]+[x[0] for x in c['boxes']]+[u[0] for u in c['ub']]); inc[c['ch']].update(range(c['start'],last+1))
E=[tuple(e) for e in json.load(open('appA_cardlocal.json'))]
G=json.load(open('appA_g4.json'))
def regrow(ch, pid, words, exclude):
    L=b.lines(ch); best=[]
    for n,s in enumerate(L,1):
        if n in inc[ch] or n==exclude or not s.startswith('| ') or 'NOT DECIDED' not in s and 'No separate' not in s: continue
        k=cells(s)
        if len(k)<2: continue
        if pid and pid not in k[0]: continue
        if all(w.lower() in s.lower() for w in words): best.append(n)
    return best
FIELDWORDS={'Whole-path stamp':['stamp'],'Stamp':['stamp'],'Trigger':['Trigger'],'Exit':['Exit'],}
unres=[]; g4=[]
items=[(k,ch,n,cel) for (k,ch,n,cel) in G['found']]
for u in G['un']:
    k=u[1]; ch=k[1].split(':')[0]; oldn=int(re.match(r'CH[\w\-]+:(\d+)',k[1]).group(1)); cel=re.search(r'cell (\d+)',k[1]); cel=int(cel.group(1)) if cel else None
    pid=re.match(r'^((?:C|P|CY)-[A-Za-z0-9][A-Za-z0-9\-]*)',k[2]); pid=pid.group(1) if pid else None
    if u[0]=='several':
        cand=u[2]
        pick=oldn if (ch=='CH11' and oldn in cand) else next((n for n in cand if b.lines(ch)[n-1].startswith(f'| {pid} |')),None)
        if pick: items.append((k,ch,pick,cel)); continue
    else:
        m=re.match(r'^USED BY \d+ / (Takes in there|Changes there) / (.*)$',k[3])
        if m:
            ui=m.group(2); hits=[n for n,s in enumerate(b.lines(ch),1) if s.startswith(f'| {pid} — ') and ui in s and 'NOT DECIDED' in cells(s)[cel-1]]
            if len(hits)==1:
                k=list(k); k[3]=f'Continuation USED BY / {m.group(1)} / {ui}'; items.append((tuple(k),ch,hits[0],cel)); continue
    unres.append(k)
for (k,ch,n,cel) in items:
    num,loc,part,field,val,named=k[:6]
    pid=re.match(r'^((?:C|P|CY)-[A-Za-z0-9][A-Za-z0-9\-]*(?:\.[0-9A-Za-z]+)*)',part); pid=pid.group(1) if pid else None
    s=b.lines(ch)[n-1]
    v=val.replace('\\|','|')
    if v!='NOT DECIDED' and v not in s and cel is None: v=s.strip()   # line text changed (e.g. a tag): copy the v2 text
    nm=named
    mm=re.search(r'Register: (CH[\w\-]+):(\d+)',named)
    if mm and ch=='CH11' and pid and pid in b.lines('CH11')[int(mm.group(2))-1]:
        g4.append((ch,n,cel,part,field,v,nm)); continue
    if mm:
        words=FIELDWORDS.get(field,[w for w in re.findall(r'[A-Za-z]{4,}',field)[:3]]) if not field.startswith('Continuation') else [field.split(' / ')[1]]
        if field.startswith('Step'): words=[field]
        r=regrow(ch,pid,words,n)
        if field.startswith('Continuation'):
            r=[x for x in r if 'Continuation USED BY' in b.lines(ch)[x-1] and field.split(' / ')[2].split(' — ')[0] in b.lines(ch)[x-1]]
        nm=re.sub(r'Register: CH[\w\-]+:\d+', f'Register: {ch}:{r[0]}' if r else 'Register: NOT FOUND', named)
        if not r: unres.append(('register',k))
    g4.append((ch,n,cel,part,field,v,nm))
print('non-card entries placed:',len(g4),' unresolved:',len(unres))
for u in unres[:12]: print('   unresolved:',str(u)[:160])
ALL=E+g4
seen=collections.Counter((e[0],e[1],e[2]) for e in ALL); dup=[k for k,v in seen.items() if v>1]
print('total entries:',len(ALL),' duplicate locations:',len(dup),dup[:5])
json.dump({'all':ALL,'unres':unres},open('appA_all.json','w'),ensure_ascii=False)
