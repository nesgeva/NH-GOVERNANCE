import sys, re, collections; sys.path.insert(1,'/home/claude/m21/v2'); sys.path.insert(2,'/home/claude/m21/tools')
import m21, v2check
TOG=('Fed by','Gated by','Changes'); RFG=('Must never','Fails closed by','Gated by')
IDN=r'(C-[A-Za-z0-9][A-Za-z0-9\-]*(?:\.[0-9A-Za-z]+)*)'
def cites(lines, nhd=False):
    out=set()
    for s in lines:
        for c in re.findall(r'\[[^\[\]]+\]',s):
            if re.match(r'\[(V10|DD|CR|COMP|MAP|DR|04/|05/|05i/|98/)',c) or (nhd and c.startswith('[NHD')): out.add(c)
    return out
def compute(get, ch, cards):
    cs=[c for c in cards.values() if c['ch']==ch]; ids={c['id'] for c in cs}; chap={cid:c['ch'] for cid,c in cards.items()}
    L=get(ch); M={}
    M['cards']=len(cs)
    M['box_lines']=sum(len(c['boxes']) for c in cs)
    M['used_by_rows']=sum(len(c['ub']) for c in cs)
    ep_int=ep_ext=0; named_lines=0; plain=0; pairs_int=set(); pairs_ext=set(); plain_gate=0; named_int_lines=0; named_ext_lines=0
    for c in cs:
        for (n,bx,t) in c['boxes']:
            if bx not in TOG or t.strip()=='NOT DECIDED': continue
            ends=[x for x in v2check.names_in(t,cards)]
            if ends:
                named_lines+=1
                for x in ends:
                    if chap.get(x)==ch: ep_int+=1; pairs_int.add((c['id'],x))
                    else: ep_ext+=1; pairs_ext.add((c['id'],x))
            else:
                plain+=1
                if bx=='Gated by': plain_gate+=1
    M['ep_internal']=ep_int; M['ep_external']=ep_ext; M['ep_total']=ep_int+ep_ext
    M['named_together_lines']=named_lines; M['plain_together_lines']=plain; M['plain_gates']=plain_gate
    M['internal_use_pairs']=len(pairs_int); M['external_use_pairs']=len(pairs_ext)
    M['rfg_lines']=sum(1 for c in cs for (n,bx,t) in c['boxes'] if bx in RFG)
    M['rfg_empty']=sum(1 for c in cs for (n,bx,t) in c['boxes'] if bx in RFG and t.strip()=='NOT DECIDED')
    M['nd_boxes']=sum(1 for c in cs for (n,bx,t) in c['boxes'] if t.strip()=='NOT DECIDED')
    M['populated_boxes']=M['box_lines']-M['nd_boxes']
    M['nd_cells']=sum(sum(1 for x in u[3].split(' | ')[1:4] if 'NOT DECIDED' in x) for c in cs for u in c['ub'] if u[3].split(' | ')[0].strip()!='NOT DECIDED')
    M['nd_tables']=sum(1 for c in cs if c['ub'] and all(u[3].split(' | ')[0].strip()=='NOT DECIDED' for u in c['ub']))
    M['empty_together_cards']=sum(1 for c in cs if all(t.strip()=='NOT DECIDED' for (n,bx,t) in c['boxes'] if bx in TOG))
    sp=sum(len(re.findall(r'(?<![\w.\-])'+IDN,x)) for x in L if x.startswith('SUB-PARTS:'))
    M['subpart_refs']=sp
    M['built_box_lines']=sum(1 for c in cs for (n,bx,t) in c['boxes'] if t.startswith('BUILT'))
    M['external_uses']=0
    for c in cs:
        for u in c['ub']:
            m=re.match(IDN,u[3].split(' | ')[0].strip())
            if m and m.group(1) in chap and chap[m.group(1)]!=ch: M['external_uses']+=1
    M['cite_whole']=len(cites(L)); M['cite_whole_nhd']=len(cites(L,True))
    inc=set()
    for c in cs:
        last=max([c['start']]+[x[0] for x in c['boxes']]+[u[0] for u in c['ub']]); inc.update(range(c['start'],last+1))
    M['cite_cards']=len(cites([L[n-1] for n in sorted(inc)]))
    M['cite_behavior']=len(cites([L[n-1] for n in sorted(inc)]))
    return M

def cont_rows(L, which=None):
    """physical data rows in tables under headings that name cross-piece continuations"""
    n=0; head=''; hdr=False; out=collections.Counter()
    for s in L:
        if s.startswith('#'): head=s; hdr=False; continue
        if not s.startswith('|'): hdr=False; continue
        if 'ontinuation' not in head or 'CONTRACT CHECK' in head or 'READ RECORD' in head: continue
        if not hdr: hdr=True; continue          # header row
        if re.match(r'^\|[\s\-:|]+\|?\s*$',s): continue   # separator
        kind='TOGETHER' if 'TOGETHER' in head else 'USED BY' if 'USED BY' in head else 'other'
        out[kind]+=1
    return out
def gaps_variants(get,ch,cards):
    M=compute(get,ch,cards); L=get(ch)
    reg=0; inreg=False
    return {'nd_boxes':M['nd_boxes'],'boxes+cells':M['nd_boxes']+M['nd_cells'],'boxes+cells+tables':M['nd_boxes']+M['nd_cells']+M['nd_tables'],'boxes+tables':M['nd_boxes']+M['nd_tables']}
