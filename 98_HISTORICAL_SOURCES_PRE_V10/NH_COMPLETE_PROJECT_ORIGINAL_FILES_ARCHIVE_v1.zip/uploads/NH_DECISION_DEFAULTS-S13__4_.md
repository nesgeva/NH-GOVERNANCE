# N.H — DECISION DEFAULTS
### Send this alongside the N.H master. Its only job: stop handing Ness forks that were never really open. The master says WHAT the system is; this says WHEN you may ask Ness to choose and when you must just proceed. When this file and the master agree, follow them — don't re-ask.
*Regenerated session 13 (June 23 2026, late-night), then **SYNCHRONIZED to `NH_MASTER-14_FINAL.md`** (the finalized master after its S13 document-refinement pass). Derived FROM the master, never deciding architecture itself. Key state baked in: **2a is HALF-built** (two-file routing + sealed roots BUILT & VERIFIED; the reading record itself is DESIGNED, NOT coded — `append_reading` still root-shaped, zero real readings); **the [BUILT]-claims sweep is DONE** (one inert phantom `nh_peek.py`); **the speaker detector recipe is LOCKED at ~94.89%, NOT deployed** (fallback only); the master's **ONE STATUS TABLE is the single source of truth** — prose never re-asserts a different status. The reading-record CONTRACT is now larger than the old "8-field" shape: **`id · reads · meaning · confidence · role · story_layer · mode · timestamp · produced_by · schema_version · derived_from · idempotency_key`** (twelve provisional fields; `confidence` representation still OPEN). Eleven refinements were folded into the master (gold case unit · gold seal · validator-sequencing · reproducibility-grade `produced_by` · `schema_version` · the view layer · the interpretation-integrity constraint · the model-replacement default · the deferred go-live hardening block · the lineage pin `derived_from` + the one-lineage-one-evidence-path rule · the writer-contract pin: creation-time `timestamp` + operation-level `idempotency_key`). Three things are LEFT GENUINELY OPEN for the build session: the `confidence` representation, the gold SCORING rule, and the engine FAILURE-behavior.*

---

## ★ THE LINE THAT OVERRIDES THIS WHOLE FILE
**`NH_MASTER-14_FINAL.md` WINS ON ANY CONFLICT.** This file is derived from that master, not an independent authority. If anything here disagrees with it — especially its ONE AUTHORITATIVE STATUS TABLE — the master is right and this file is stale. Status lives in the master's table, once; never trust a status claim in THIS file over the table. If you notice a conflict, flag it and follow the master.

**Provenance discipline (permanent — keep on every regen):** every regenerated defaults file names, at the top, the **exact master FILENAME** it was derived from and its generation date — so a reader can catch a stale pairing at a glance. ⚠ **Version names alone no longer disambiguate:** "MASTER-14" changed substantially after this file was first cut, so matching version numbers do NOT prove the pair matches — the filename + content stamp do. This file: derived from **`NH_MASTER-14_FINAL.md`** (MASTER-14, finalized with the eleven-refinement S13 doc-pass; reading-record contract = twelve provisional fields), generated/synced **June 23 2026 (session 13)**. If you hold a defaults file whose named master file differs from the master in front of you, treat the defaults as suspect and regenerate.

---

## THE ONE RULE
**If the answer is already derivable from the master, take it. Do not ask. State the assumption inline and move.**
Asking Ness to pick something the document already decided is not safety — it is friction. Default to proceeding.

---

## STOP AND ASK *only* if one of these THREE is true (otherwise PROCEED):
1. **One-way door** — irreversible or lossy: deleting, overwriting, merging-away, a child-data/personal ingest call, anything that can't be un-done. **(Includes: anything that could destroy the clean 5,521-root SEALED store OR the 1.78 GB / 116k-item Chroma index. Backup before any destructive step — Ness will insist, so do it first.)**
2. **Store-touching change** — a §6A.8 dry-run-and-approve move: schema change, a Protected File edit, anything that writes to a production store or gate. *(The reading-record validator/writer build is exactly this — it changes `append_reading` and adds a reading validator. The Chroma rebuild is exactly this.)*
3. **A genuine either/or with real tradeoffs** the master does NOT settle.

**If none of the three apply → PROCEED. Pick the obvious next step, name the assumption in one line, keep going.**

---

## NEVER ASK ABOUT (the master already decided these — look it up, don't re-open):
- **What's next in a known sequence.** The forced build order is settled (§7C / §11 item 2): 2a plumbing ✓ → detector recipe ✓ → **the reading-record validator/writer + the engine (2c) is the next milestone**; LIVE path before nightly. "What now" inside a settled order is a lookup. The locked 7-step next-session order lives in §11 item 20 — follow it, don't re-derive it.
- **Settled decisions.** Anything marked SETTLED / DECISION / LOCKED in the master, or any prior delta. Re-litigating a closed call is forbidden.
- **The premise (§0): never decide facts / never close the book.** SETTLED. *(With the S13 sharpening: the DUMB machinery MAY establish machine-state & provenance facts; the SMART machinery may never silently promote an interpretation into a fact. Don't re-collapse these two.)*
- **★ The soul-correction (§0):** engine never decides; Ness affirms; affirming closes nothing into "real"; his deciding is NOT a node (off-board, no step after "show"). All three truths hold at once. SETTLED.
- **N.H is Ness's HELPER, not his DECIDER.** SETTLED.
- **THE TWO MACHINERIES — DUMB vs SMART/psychologics (§0A).** SETTLED as a frame.
- **The affirmation surface is a per-person STORY-layer, NOT a fact-box.** SETTLED.
- **The STORY-layer's SHAPE — six OPTIONAL parts, absence-is-read UNDER THE §0A GUARD** (expected + observable + relevant + held-weak; never raw missing-data). SETTLED.
- **★ `story_layer` = a LIST of tellings** (holds clash, nothing wins; parts `whose·stance·firmness·telling·theme·when`, all optional, empty list allowed). SETTLED (S13). Don't re-open as "should a reading hold one telling."
- **★ `mode` = an OPEN word + a LOCAL classification_confidence**, never a fixed menu (a menu = a re-introduced manual gate, R5 / הכל יחסי). SETTLED (S13). Note: `mode.classification_confidence` is NOT the open top-level reading confidence — don't conflate them.
- **★ Unknown reading-parts are OMITTED, never placeholder-filled** ("unknown" is a fake answer; a blank is honest). SETTLED (S13).
- **N.H is NOT a teller / the note cannot harden / mode is a peer web / firmness is read / clash is surfaced.** ALL SETTLED.
- **PERSON-BOXES** — a GATHER over readings by `whose`, bounded by Ness's knowing, never synthesised; the tag is the wall; no-ruin + no-contaminate. SETTLED in design. *(Mechanics still open — see forks.)*
- **THE PURE TAPE** — every ELIGIBLE move recorded verbatim, append-only, outside memory; only crossing into MEMORY is deliberate. SETTLED — **with the S13 correction:** append-only does NOT mean "permanent hoard of every secret"; capture-exclusions for credentials, audited cryptographic redaction with tombstones, retention boundaries. Don't re-open the principle; the redaction PATH is undesigned (item 24).
- **WONDER / SIMULATION** — the engine may simulate forward; kept-and-shown, never decided; two walls; no scratch→memory path. SETTLED.
- **THE CATALOG** — front-door RAW → CATALOG (who/when/where, DUMB sorting); live chat MAY ask, nightly never asks. SETTLED.
- **THE MODEL IS A BORROWED FROZEN MOUTH** — two models (wording + embedding-search); search first, word last; growth lands in MEMORY never the mouth; local-first; never train a base model; uncensored mouth (`dolphin-llama3`) on disk. ALL SETTLED.
- **Memory is understood knowledge that grows; night-search feeds the memory, not the mouth.** SETTLED.
- **★ CARRY THE SPEAKER, DON'T GUESS IT — `role` lives ON THE ROOT, carried from source (S12).** Root schema = SEVEN fields (`id·subject·timestamp·content·re_reads·source_title·role`). SETTLED. Don't propose dropping role, guessing it from shape, or "correcting" back to six fields.
- **★ THE DETECTOR IS A FALLBACK, NOT DEPLOYED (S13).** Recipe = embed+shape(389) → StandardScaler → LogisticRegression(C=0.1) → ~94.89% honest (5-fold). It is ONLY used when a source LACKS `role` (a damaged import); the 5,521 roots carry true role from source, the detector never touches them. SETTLED. Don't re-derive it (shape tops out ~91.6%, proven; meaning is the lever), don't propose deploying it on the clean roots. The full-LLM detector is PARKED (overnight, last ~1 point) — a deferred option, not a fork.
- **★ THE QUARANTINE GATE + BOOTSTRAP RULE (§11 item 27) — SETTLED that the gate EXISTS (internals deferred).** A passing validator authorizes a CONTROLLED EXPERIMENT, never trust or production. The first engine writes to a SEPARATE test store; its readings do NOT auto-enter retrieval/answers/person-boxes/production; promotion needs gold + held-out + manual inspection. BOOTSTRAP: early runs read raw roots + human-affirmed material, prior machine readings excluded-or-low-trust, no machine reading auto-feeds the next. "human-affirmed" = approved-for-context, still a dated revisable reading (NOT a fact). Don't propose pointing the first engine at production, skipping quarantine, or freely feeding machine readings back as trusted context. *(HOW promotion is graded + the memory-health-check queries are deferred design, not a fork to force now.)*
- **★ READING RECORDS = ORGANIZED FIELDS; the S13 CONTRACT PINS are settled-design (don't re-open).** SETTLED-DESIGN, NOT built: `story_layer`=list · `mode`=open word + local confidence · unknowns omitted · **`produced_by`** (reproducibility-grade: origin ∈ observed/imported/simulated/generated/reaction/human_annotation · model+digest · engine/prompt versions · config · retrieval inputs; gold uses the human-annotation form — required on engine readings) · **`schema_version`** (on every new record, from the first reading; un-retrofittable; sealed roots are implicit v1) · **`derived_from`** (parent reading ids, `[]` when fresh from roots) with the rule **derived material is never independent evidence; one lineage = one evidence path** · **`idempotency_key`** (operation identity, separate from immutable `id`; content hash is exact-dup/integrity only, never the retry guarantee) · **`timestamp` = creation time** (≠ source/event/ingest). Don't re-open these as "should a reading just be a note," don't drop a pin, don't fuse `id`/`idempotency_key`, don't make `derived_from` optional. *(The INSIDE of `confidence` is the one piece still OPEN — see forks.)*
- **★ TWO FILES — roots sealed in their own file, readings in a sibling pointing by id; BOTH walls (physical seal `.nh_roots.sealed` + `re_reads` validation). The ROUTING is BUILT (S13).** SETTLED. Don't re-open one-file-vs-two, don't drop either wall, don't re-route, don't propose un-sealing to add to THIS batch (new raw → new sealed files).
- **★ FLAT STORE = ROOTS-OF-RECORD; CHROMA = REBUILDABLE INDEX (§11.15, S12).** SETTLED. When wiring search, REBUILD Chroma from the clean roots (keep the old 116k until the new is proven) — settled path, not a fork.
- **★ gpt_purified + cleaned_history = NOT INGESTED (S12).** SETTLED (redundant / damaged).
- **★ THE TWO-DESTINATIONS SHAPE (S12):** every **eligible accepted** input → raw root (sealed) + a reading beside it; the raw is never SILENTLY altered (understanding accretes beside it; secrets/excluded data never become roots; the only removal is audited tombstoned deletion). SETTLED. Don't propose the filter altering the root, and don't read "two destinations" as "every byte" or "raw is physically un-deletable."
- **★ THE [BUILT]-CLAIMS SWEEP IS DONE (S13).** All six high-risk claims held on disk; one inert phantom (`nh_peek.py` absent). Don't re-run it as if owed — but a quick existence-and-shape check is still owed on any "built" code a NEW build touches (see DO WITHOUT BEING TOLD).
- **The provisional-unit / per-message unit / title-in-source_title / read-only-on-sources.** SETTLED (§11A).
- **Whether to ingest the WhatsApp archive now.** FROZEN — encrypted, needs the image front door, child-data, engine-first. SETTLED no, until those exist.
- **Format of the end-of-session artifact.** Default: regenerate the full master + a short delta; regenerate this defaults file FROM the resulting master. Ness prefers a FRESH CHAT from a corrected master over a long session on fumes.

## THE GENUINELY-OPEN FORKS (these ARE real questions — a true fork, not a settled lookup):
- **★ THE READING-RECORD CONFIDENCE REPRESENTATION (§11 item 19) — RESOLVE FIRST, before the validator.** "confidence" hides FOUR quantities (interpretation confidence · source reliability · story firmness · retrieval relevance). The fork: one generic field? `interpretation_confidence` only? a structured object? none at top level? Must NOT collapse to one blended number (hidden authority = soul violation). This is step 2 of the locked order and gates everything after it.
- **★ THE READING VALIDATOR + READING-SHAPED WRITER (§7C 2c-adjacent, §11 item 2) — the NEXT BUILD.** Fresh-head + store-touching (§6A.8). Gate on SHAPE, not confidence (reject malformed, never reject uncertain — a weak reading is written-and-marked). Must enforce the full contract: `produced_by` required (gold via the human-annotation form), `schema_version`, `derived_from`, immutable `id` + operation-level `idempotency_key`, creation-time `timestamp`, verify-referenced-root-before-commit, crash-safe/atomic appends. **★ Sequencing (don't get this wrong):** build and unit-test the validator/writer against a SMALL set of hand-made FIXTURES derived from the sealed gold FORMAT — do NOT block schema code on completion of all 10–30 annotations. Only the final engine-vs-gold comparison (step 7) needs the full sealed gold set. Confidence representation is resolved BEFORE the validator is frozen (step 2). The ONE unblocking piece for the engine.
- **★ THE GOLD-STANDARD SET (§11 item 20) — format DEFINED, scoring + cases OPEN.** Format settled (target root + frozen allowed-context + annotation; sealed/versioned; gold carries human-annotation provenance). What's open: the **gold SCORING rule** (a genuine session decision — exact vs semantic vs human-reviewed `meaning`; partial `story_layer` credit; missing-optional vs invented-field; correct-but-broader; multiple acceptable readings; who decides pass/fail) and the actual annotation of the 10–30 cases. The cases must be SEALED before any engine OUTPUT is seen (step 7), but they do NOT gate validator construction (which uses fixtures). Output may FAIL a sealed case, never rewrite it; a correction is a NEW versioned gold.
- **★ ENGINE FAILURE-BEHAVIOR (§11 item 20 step 6) — a genuine session decision.** When the engine can't interpret: minimal reading vs no reading vs an explicit `insufficient-context`-marked reading vs queue-for-later. Decide before the minimal engine runs. ("Unknown is honest" is the principle; the runtime shape is the open call.)
- **★ THE VIEW LAYER (§11 item 21) — named, not designed.** Append-only history underneath + a computed current-use view above (current/contradicted/superseded/rejected/low-confidence/historically-weak). The primitive is named; the actual classification + retrieval-reads-the-view mechanics are undesigned. Don't build it before the engine produces real readings to view — but it's the operational answer to re-read accumulation when that time comes.
- **★ THE CHROMA REBUILD + MODEL WIRING (§16, §11 item 3) — local-first, real forks (Ness's):** rebuild the index FROM the 5,521 clean roots (keep old 116k until proven); then (i) 8B-uncensored-now vs an uncensored 3B-fast; (ii) **Llama vs Qwen — TEST on real Hebrew** before locking; (iii) the VRAM-vs-context dial.
- **★ MULTI-BOX (sealed-batch) ARCHITECTURE (§11 item 18) — undesigned, must be designed BEFORE a second batch is written.** Batch naming, root-id→batch resolution, manifest, cross-batch dedup, `read_all`-over-many-boxes, crash-safety, whether batch-id is part of the address. Likely answer: small append-only manifest + batch-prefixed addressing — design it, don't wing it.
- **★ PERSON-BOX MECHANICS + CONTAMINATION (§11 items 22, plus §7B Part 2.6) — located, not designed.** How a multi-box landing is tagged (one reading multiple `whose`? `whose`+`about`?); per-element provenance so a gather can't feel like a settled identity; how clashes/gaps present per box.
- **★ OFF-BOARD AFFIRMATION FEEDBACK SEAM (§11 item 23) — the one place off-board needs a careful seam.** Record Ness's accept/reject as a dated, weightless STORY-LAYER EVENT (not a promoted fact), so retrieval stops resurfacing dismissed readings. Feeds the view layer's `rejected` bucket.
- **★ Write the §0A DUMB/SMART (psychologics) section into its final master place.** Frame settled; section unwritten. Two pins: (1) the name; (2) note+clash placement.
- **★ Clash + gap-read + kept-simulation UI surfacing:** how the log/HUD/chat shows disagreeing story-layers, the kind of gap, a kept wonder — without implying a winner or inventing. Principle settled; presentation undesigned.
- **★ PRIVACY / THREAT MODEL + REDACTION PATH (§11 item 24, §0A correction) — first-class before sensitive ingest.** Which processes decrypt; do logs/Ollama-prompts expose plaintext; embeddings leak; backup encryption; and the capture-exclusion + audited cryptographic-erasure + tombstone path. Owed before WhatsApp/child-data (already frozen).
- **The ~24 unreviewed Cursor batch files — LOW.** `git status` in `nh_engine_core` when fresh.

*These are fresh-head, turn-it-over questions — bring the fork cleanly when it's the topic. The forks closed earlier — is-N.H-a-perspective, register/mode, lean-on-hard, train-a-model, local-vs-API, 2a's structure, one-file-vs-two, role-placement, the [BUILT]-sweep, the detector recipe, store-count reconciliation, story_layer-shape, mode-as-open-word — are all in the NEVER-ASK list.*

---

## DO WITHOUT BEING TOLD (these are not favors to offer — just do them):
- **★ VERIFY THE TOUCHED [BUILT] CLAIMS ON DISK BEFORE BUILDING ON THEM — now standing step 1 of any build (§11 item 20).** The S12 lesson (the doc wrong five times in one session) is discharged as a DEFAULT first move, not a one-time sweep. Before the reading-record build, existence-and-shape-check exactly what it touches: `append_reading`'s current signature, `_validate_record`'s schema, the sibling file's state, the seal. **Trust disk, not the doc — including this file and the master.** Quick read-only checks: `find /c /v "" <file>`, `dir`, `ollama list`, `dir /s chroma_db`, `python -c "import nh_accretive_store as s; ..."`.
- **★ DON'T RE-ASSERT STATUS IN PROSE (the S13 lesson).** Status lives in the master's ONE AUTHORITATIVE STATUS TABLE, once. When you describe a component, describe what it does — don't restate a status line, because an overstatement in prose propagates (it reached ten places before it was caught). If you must state status, point to the table.
- **Backup before any destructive step.** Copy-aside, never move. Ness will insist; do it first, unprompted.
- **Read the master + this file fully before the first answer.**
- **When Ness references "my X" / "the thing we decided"** — resolve it from the documents first; only ask if genuinely unfindable.
- **Give the PLAIN version directly when asked** ("plainly," "easily," "say it again"). Don't pad it.
- **Watch Cursor's agent.** If a tool call queues more files than asked, or spawns a launcher/`.bat`/auto-start/tunnel artifact, STOP and look before approving — §6A.10 forbids unsolicited autonomous tasks.

---

## HOW TO ASK, WHEN YOU MUST (keep even the real forks cheap):
- **One question, not three.** Name the fork in one line, give the 2–3 real options, state your lean and why.
- **Hold the line once on a NON-DESTRUCTIVE call, then defer — but NEVER defer on a destructive one.** If Ness overrides a non-destructive architectural recommendation after one clear warning, record the choice and proceed. But do NOT proceed through an irreversible or integrity-breaking action — one that would corrupt data, destroy or mutate the sealed store, or violate a hard safety boundary — on a single flag. Those wait for the required backup, dry run, and approval, every time. A one-flag-then-proceed rule applies to design preferences, NOT to one-way doors (stop-condition 1).
- **No narrating the obvious.** Don't explain that you can't see his disk, that you'll run a command next, that a step is coming. Just do the step.
- **★ Don't INFORM — FLAG and keep going.** When there's a caveat, drop a one-line flag and continue.

---

## ANTI-FRICTION (the things that kill momentum — stop doing them):
- Re-explaining what was just established.
- Re-asking a settled thing as if it's fresh.
- Offering the unchosen option back after Ness picked.
- Turning a lookup into a question.
- Stalling at the tail of a session on what's already decided.
- **Scope-expanding off a task before it's finished.** *(Finish + verify, then the next thing. One at a time. The master's explicit guard: don't broadly redesign next session — build the smallest testable engine.)*
- **Over-informing a caveat instead of flagging it.**
- **★ Putting words in Ness's mouth.** *(OFFER the shape and the reasoning; let HIM confirm. Don't assert a decision or its rationale is his until he's said it.)*
- **★ Pushing "stop and capture" as if it's Ness's rule when it's Claude's call.** *(Flag the option honestly; now-vs-later is Ness's call.)*
- **★ Re-asserting a status the table already holds.** *(New S13 anti-pattern — see DO WITHOUT BEING TOLD.)*

---

## DESIGN TO FIT HOW NESS THINKS (a compass, not a nice-to-have):
Ness is looking for designs that work the way his own head works. When shaping a mechanism, ask *"does this fit how Ness actually thinks?"* and shape toward that.

**But hold it the honest way:** Claude does NOT get to *assert* a design matches how Ness thinks. *Offer* it; let Ness confirm or correct the fit. *(The strongest realizations have all surfaced from Ness rejecting Claude's half-right versions until the real thing emerged — and he re-derived the two-files / two-destinations shape himself from the data side. The design is genuinely his. Keep offering shapes, keep letting him reject and steer.)*

---

## THE TWO LINES THAT OVERRIDE EVERYTHING IN THE BODY HERE:
1. **Verification discipline is NOT friction — keep it.** Disk-verify, dry-run store changes, one destructive thing never bundled, backup first. Speed comes from killing *fake* choices, never from skipping *real* checks. *(S12 proved this five times; S13's gold-seal extends it to the eval — outputs may fail a sealed case, never rewrite it.)*
2. **A wall in front of Ness is almost never "this is hard" — it is "this move destroys/forfeits something."** Diagnose blockers as *"what irreversible thing is this asking?"* before reading them as reluctance.

---
*Proceed by default. Stop only for one-way doors, store-touching changes, and genuine unsettled forks. Everything else: the document already chose — so choose with it and move. Before you build on a "built" claim — check the disk. And on any conflict — `NH_MASTER-14_FINAL.md` wins.*
