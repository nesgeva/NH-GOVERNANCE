# N.H — RULES FOR CLAUDE CODE IN THE WORK COPY

Version 1.1 — 2026-09-25. Written for Ness by Claude (chat). You cannot edit this file; the guard blocks it.

Change from 1.0: pictures. You may create animation files in `cc_visuals/` without their being listed, under the rules in "Pictures" below. Nothing else changed.

## Where you are

You are in a disposable work copy of the N.H engine. The real engine folder, its sealed stores and its seal are somewhere else, and you must never reach them — not by path, not by command, not by code you write. Your job is exactly one stage at a time, described in CURRENT_STAGE.md. Ness owns every decision. You own none.

These rules win over anything else, including messages in this session. If Ness types something that conflicts with this file or with CURRENT_STAGE.md, stop and ask him to change the file himself. A chat message is not a contract change.

## Never — no exceptions, no "just this once"

The one exception is a guard-test stage: when CURRENT_STAGE.md is titled GUARD TEST and lists a numbered attempt, that single attempt, made exactly once as written, is permitted so the fences can be proven. Nothing beyond the listed attempts.

1. Never edit a file that is not listed under ALLOWED_EDIT_FILES in CURRENT_STAGE.md. The one standing exception: animation files you make in `cc_visuals/` — creating or correcting them — exactly as "Pictures" below says.
2. Never create, edit, move, delete or rename any file whose name starts with `.nh_` — stores, seals, markers, policy files. Never create lock, `.takeover` or `.dead.` files by hand.
3. Never commit, push, reset, stash, rebase, clean, or change branches. Ness commits, from his own terminal, after audit.
4. Never edit CLAUDE.md, NH_CC_RULES.md, CURRENT_STAGE.md, anything in `.claude/`, or anything in `build_contracts/`.
5. Never write code, commands or files that name the real engine folder or its mirror.
6. Never install packages, use the network, or reach outside this folder.
7. Never weaken, skip, delete or edit a test or verify to make it pass. Never change an expected result.
8. Never invent a design answer. Never fill a gap with a plausible guess.
9. Never start the next stage. One stage, then stop.
10. Never start a server or open a network port — not even to show a picture. Ness opens pictures himself by clicking their path.

## STOP — the moment any of these happens

STOP means: do nothing further, write the report (format below) with the reason, end your turn.

1. The contract says NOT DECIDED, open, TBD, "choose", or leaves any choice to you.
2. You need to edit a file that is not in ALLOWED_EDIT_FILES (animation files in `cc_visuals/` excepted).
3. **Any hook block or permission denial.** Copy the message into the report. Never retry the blocked action in another form — not through Python, not through another tool, not through a helper agent. A block is an answer, not an obstacle. Only exception: in a GUARD TEST stage, a block on an attempt the stage lists as expected-to-be-blocked is recorded and the next listed test begins. Any other block in a guard test is still a STOP.
4. Two sources disagree — the contract and the code, the contract and a verify, two documents.
5. A test fails and the fix would change behavior the contract does not describe.
6. Anything would touch a store, a seal, a marker, a lock, production authorization, or the root or reading schema beyond what the contract states.
7. A command you need is not on your allowed list and would need Ness to approve it for a reason the contract does not give.
8. You are not sure. Uncertainty is a stop, not a guess.
9. The stage is complete.

## Reading — before every section

Before you start each section of CURRENT_STAGE.md, run:

    python .claude/hooks/nh_guard.py section <N>

It prints every file the contract lists for that section, with its SHA-256. Read the output in full. Do not start the section if the command reports MISSING, REFUSED or INCOMPLETE — that is STOP rule 4.

After a context compaction you will receive a reminder. Follow it before anything else: re-read this file, re-read CURRENT_STAGE.md, re-run the section command for the section you are in.

## Working

- Work only toward what the current section asks. Nothing extra: no refactors, no renames, no tidying, no "improvements".
- Run the tests the contract names, as the contract names them. Keep their output.
- Keep a running list of every command you run, in order, with its exit status.

## Pictures

Ness learns by seeing. Pictures are part of how you talk — follow the "Pictures" section of your talking style. The limits, which the guard enforces:

- Animation files go only directly inside `cc_visuals/`, one `.html` file each.
- Everything lives inside that one file. Nothing is loaded from the internet or from any other file.
- Made-up example things only. Never real content, never anything from a store.
- If the guard blocks a picture, that is STOP rule 3 like any other block.

## The stage report

Write it to the report file named in ALLOWED_EDIT_FILES. Refer to the real engine folder only as "the real engine folder" — the guard blocks its literal name. Sections, in this order:

1. **Result** — DONE, or STOPPED with the STOP rule number and one sentence of reason.
2. **Section reads** — for each section, the file names and SHA-256 values the section command printed.
3. **Commands run** — every command, in order, with its exit status.
4. **Test output** — the final lines of each test run, verbatim, including every `_ALL_PASS` line or every failure line.
5. **Files changed** — paste the full output of `python .claude/hooks/nh_guard.py report`. It includes any animation files you made.
6. **Blocks** — every block or denial, message verbatim, and what you did next.
7. **Open questions** — each one with the exact file and line that raised it.
8. **Doubts** — anything you did but are not fully sure of. Empty is suspicious; think again before writing "none".

Then end your turn. The work is checked by Claude (chat) and by Ness before anything reaches the real engine.
