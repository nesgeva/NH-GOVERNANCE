#!/usr/bin/env python3
"""
N.H guard for Claude Code — native Windows, work copy only.

Modes (first argument):
  pretool    PreToolUse hook. Reads the tool call as JSON on stdin.
             Exit 2 blocks the call. Exit 0 lets permission rules decide.
  reinject   SessionStart hook (matcher "compact"). Prints a rules reminder
             into Claude's context after every context compaction.
  section N  Prints every file listed under "SECTION N READS:" in
             CURRENT_STAGE.md, each with its SHA-256 and full text.
  report     Prints SHA-256 of every file changed or added versus git HEAD,
             harness files excluded.

Fail-closed: in pretool mode, any error inside this script blocks the call.
Visuals: single self-contained .html files in cc_visuals/ may be created without
being listed, but only if they load nothing from anywhere (see check_visual).
This guard is a fence, not a vault. It cannot see inside a script that a
permitted command runs. The 8-store hash check and the audit stay the proof.
"""
import sys, os, json, re, hashlib, subprocess

FORBIDDEN_PLACES = ["nh_engine_core", "nh-engine-code"]   # real engine folder, and its mirror
HARNESS_FILES = {"claude.md", "nh_cc_rules.md", "current_stage.md"}
HARNESS_DIRS = (".claude/", "build_contracts/")
STAGE_FILE = "CURRENT_STAGE.md"
RULES_FILE = "NH_CC_RULES.md"
EDIT_TOOLS = {"Edit", "Write", "MultiEdit", "NotebookEdit"}
READ_TOOLS = {"Read", "Grep", "Glob"}
SHELL_TOOLS = {"Bash", "PowerShell"}

# cursorrules v3.2 section 7 — Protected Files (plus the creation-gated file)
PROTECTED_CODE = {
    "nh_context_router.py", "nh_memory_store.py", "nh_evidence_integrity.py",
    "nh_reality_graph.py", "nh_epistemic_sandbox.py", "nh_simulation_graph.py",
    "nh_research_engine.py", "nh_research_sandbox.py", "nh_jarvis_core.py",
    "nh_crypto.py", "nh_auth.py", "nh_vector_memory.py",
    "nh_accretive_store.py", "nh_engine_minimal.py", "nh_engine_b.py",
    "nh_ingest_chatgpt.py", "nh_rebuild_chroma.py", "nh_baseline_engine.py",
}

GIT_WRITE = re.compile(
    r"\bgit\b.{0,40}?\b(commit|push|reset|clean|rebase|stash|merge|tag|restore|"
    r"checkout|switch|cherry-pick|revert|am|apply|update-ref|filter-branch|gc|prune|worktree)\b")
NETWORK = re.compile(
    r"\b(curl|wget|invoke-webrequest|iwr|invoke-restmethod|irm|start-bitstransfer|"
    r"ssh|scp|sftp|ftp|ncat|telnet)\b")
INSTALL = re.compile(r"\b(pip|pip3|npm|npx|yarn|pnpm|winget|choco|scoop|conda|poetry)\b")
SERVER = re.compile(r"\bhttp\.server\b|\bsimplehttpserver\b|\bsocketserver\b")

# Visuals: animation files Claude Code may create without listing, under strict content rules.
VISUALS_DIR = "cc_visuals/"
W3_NAMESPACE = re.compile(r"https?://www\.w3\.org/[\w./#-]*", re.I)
URL_SCHEME = re.compile(r"\b(?:https?|ftp|file|wss?|javascript)\s*:", re.I)
NET_CALL = re.compile(r"\b(fetch|xmlhttprequest|websocket|eventsource|sendbeacon|importscripts)\b"
                      r"|<\s*(iframe|link|object|embed|base|frame)\b|@import|\bimport\s*\(|type\s*=\s*[\"']?module", re.I)
SRC_ATTR = re.compile(r"\bsrc\s*=(?!\s*[\"']?data:)", re.I)
HREF_ATTR = re.compile(r"\b(?:xlink:)?href\s*=(?!\s*[\"']?#)", re.I)
CSS_URL = re.compile(r"\burl\((?!\s*[\"']?(?:#|data:))", re.I)


def norm(s):
    return str(s).replace("\\", "/").lower()


def sha(path):
    with open(path, "rb") as f:
        return hashlib.sha256(f.read()).hexdigest()


def block(reason):
    print("BLOCKED by N.H guard: " + reason + ". Do not retry this in any other form. "
          "Stop and report it (NH_CC_RULES.md, STOP rule 3).", file=sys.stderr)
    sys.exit(2)


def all_strings(obj):
    if isinstance(obj, str):
        yield obj
    elif isinstance(obj, dict):
        for v in obj.values():
            yield from all_strings(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from all_strings(v)


def inside(p, proj):
    return p == proj or p.startswith(proj + "/")


def stage_lines(proj_real):
    path = os.path.join(proj_real, STAGE_FILE)
    if not os.path.isfile(path):
        return None
    with open(path, "rb") as f:
        return f.read().decode("utf-8", "replace").splitlines()


def list_after(lines, header):
    """Entries written as '- item' directly under a header line."""
    out, on = [], False
    for line in lines:
        s = line.strip()
        if s == header:
            on = True
            continue
        if on:
            if s.startswith("- "):
                out.append(s[2:].strip())
            elif s == "" and not out:
                continue
            else:
                break
    return out


def load_allowed(proj_real):
    lines = stage_lines(proj_real)
    if lines is None:
        block("CURRENT_STAGE.md is missing, so no edits are allowed")
    allowed = {}
    for item in list_after(lines, "ALLOWED_EDIT_FILES:"):
        confirmed = item.startswith("CONFIRMED:")
        if confirmed:
            item = item[len("CONFIRMED:"):].strip()
        allowed[norm(item).strip("/")] = confirmed
    return allowed


def check_command(cmd, proj):
    c = norm(cmd)
    if ".nh_" in c:
        block("the command names an N.H store, seal or marker file (.nh_...)")
    if GIT_WRITE.search(c):
        block("git write operations belong to Ness alone")
    if NETWORK.search(c):
        block("network commands are not allowed in the work copy")
    if INSTALL.search(c):
        block("installing packages is not allowed in the work copy")
    if SERVER.search(c):
        block("starting a server is not allowed; Ness opens pictures himself by clicking their path")
    if "frombase64string" in c or (re.search(r"\b(powershell|pwsh)\b", c)
                                   and re.search(r"\s-e(nc(odedcommand)?)?\s", c + " ")):
        block("encoded commands are not allowed")
    if re.search(r"(^|[^\w.])\.\.([/\s'\";|&]|$)", c):
        block("the command reaches outside the work folder (..)")
    if re.search(r"(^|[\s'\"=(])~(/|\s|$)", c) or any(
            t in c for t in ("$home", "${home}", "$env:", "%userprofile%", "%homepath%", "%appdata%")):
        block("the command reaches outside the work folder (home or environment path)")
    if re.search(r"(^|\s)//[a-z0-9]", c):
        block("network paths are not allowed")
    for m in re.finditer(r"(?<![\w/])([a-z]):/[^\s'\";|,)&]*", c):
        if not inside(m.group(0).rstrip("/"), proj):
            block("the command reaches outside the work folder (" + m.group(0) + ")")
    for m in re.finditer(r"(?<![\w:/.])/([a-z])/[^\s'\";|,)&]*", c):
        as_windows = m.group(1) + ":" + m.group(0)[2:]
        if not inside(as_windows.rstrip("/"), proj):
            block("the command reaches outside the work folder (" + m.group(0) + ")")


def edit_texts(ti):
    texts = [ti.get(k) for k in ("content", "new_string", "new_source") if isinstance(ti.get(k), str)]
    for e in ti.get("edits") or []:
        if isinstance(e, dict) and isinstance(e.get("new_string"), str):
            texts.append(e["new_string"])
    return texts


def check_visual(rel, ti):
    name = rel[len(VISUALS_DIR):]
    if "/" in name or not name.endswith(".html") or len(name) <= len(".html"):
        block("visuals must be single .html files directly inside cc_visuals/ (" + rel + ")")
    for text in edit_texts(ti):
        t = W3_NAMESPACE.sub("", text)
        if URL_SCHEME.search(t):
            block("visuals must not contain web addresses; everything stays inside the one file")
        if NET_CALL.search(t):
            block("visuals must not contain network calls, embedded pages or loaded modules")
        if SRC_ATTR.search(t) or CSS_URL.search(t):
            block("visuals must be one self-contained file; nothing may be loaded from another file")
        if HREF_ATTR.search(t):
            block("visuals may only link inside themselves (href=\"#...\")")


def check_edit(ti, proj, proj_real):
    path = ti.get("file_path") or ti.get("notebook_path") or ""
    p = norm(path).rstrip("/")
    if not p:
        block("the edit names no file")
    if not p.startswith(proj + "/"):
        block("edits outside the work folder are not allowed")
    rel = p[len(proj) + 1:]
    base = rel.rsplit("/", 1)[-1]
    if base.startswith(".nh_") or base.startswith(".dead.") or ".takeover" in base:
        block("N.H store, seal, marker and lock files are never edited by hand (" + base + ")")
    if rel in HARNESS_FILES or rel.startswith(HARNESS_DIRS):
        block("the rules, the stage contract and the guard cannot be edited by Claude Code (" + rel + ")")
    if rel.startswith(VISUALS_DIR):
        check_visual(rel, ti)
        return
    allowed = load_allowed(proj_real)
    if rel not in allowed:
        block(rel + " is not in ALLOWED_EDIT_FILES of CURRENT_STAGE.md")
    if base in PROTECTED_CODE and not allowed[rel]:
        block(base + " is a Protected File (cursorrules section 7); its ALLOWED_EDIT_FILES "
              "entry must begin with CONFIRMED:")


def check_read(ti, proj):
    for key in ("file_path", "path"):
        v = ti.get(key)
        if v and not inside(norm(v).rstrip("/"), proj):
            block("reads outside the work folder are not allowed")
        if v and norm(v).rstrip("/").rsplit("/", 1)[-1].startswith(".nh_"):
            block("N.H store, seal and marker files are never read by Claude Code (private data)")
    pat = norm(ti.get("pattern") or "")
    if re.match(r"^[a-z]:/", pat) or pat.startswith("/") or pat.startswith("~") or ".." in pat:
        if not inside(pat.split("*")[0].rstrip("/"), proj):
            block("search patterns outside the work folder are not allowed")


def pretool():
    data = json.loads(sys.stdin.buffer.read().decode("utf-8", "replace"))
    tool = data.get("tool_name", "")
    ti = data.get("tool_input") or {}
    proj_real = os.environ["CLAUDE_PROJECT_DIR"]
    proj = norm(proj_real).rstrip("/")
    for s in all_strings(ti):
        n = norm(s)
        for place in FORBIDDEN_PLACES:
            if place in n:
                block("the call mentions the real engine folder or its mirror")
    if tool in SHELL_TOOLS:
        check_command(ti.get("command", ""), proj)
    elif tool in EDIT_TOOLS:
        check_edit(ti, proj, proj_real)
    elif tool in READ_TOOLS:
        check_read(ti, proj)
    sys.exit(0)


def reinject():
    proj_real = os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd())
    print("N.H RULES REMINDER - re-injected after context compaction.")
    print("Your context was just compressed. Before your next action you MUST:")
    print("  1. Read " + RULES_FILE + " in full with the Read tool.")
    print("  2. Read " + STAGE_FILE + " in full with the Read tool.")
    print("  3. Run: python .claude/hooks/nh_guard.py section <current section number>")
    print("File fingerprints right now:")
    for f in (RULES_FILE, STAGE_FILE):
        full = os.path.join(proj_real, f)
        print("  " + f + "  SHA-256 " + (sha(full) if os.path.isfile(full) else "MISSING"))
    print("Never: edit outside ALLOWED_EDIT_FILES, touch .nh_ files, commit, or work around a block.")
    print("Any block, open question, disagreement between files, or doubt = STOP and report.")


def section(n):
    proj_real = os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd())
    lines = stage_lines(proj_real)
    if lines is None:
        print("SECTION READ FAILED: CURRENT_STAGE.md is missing. STOP and report.")
        return 1
    files = list_after(lines, "SECTION " + n + " READS:")
    if not files:
        print("SECTION READ FAILED: no 'SECTION " + n + " READS:' list in CURRENT_STAGE.md. STOP and report.")
        return 1
    proj = norm(proj_real).rstrip("/")
    failed = False
    for rel in files:
        full = os.path.join(proj_real, rel)
        if not inside(norm(os.path.abspath(full)).rstrip("/"), norm(os.path.abspath(proj_real)).rstrip("/")) \
                or rel.startswith(("/", "\\")) or re.match(r"^[A-Za-z]:", rel):
            print("=== " + rel + " : REFUSED (outside the work folder) ===")
            failed = True
            continue
        if not os.path.isfile(full):
            print("=== " + rel + " : MISSING ===")
            failed = True
            continue
        with open(full, "rb") as f:
            raw = f.read()
        print("=== " + rel + "  SHA-256 " + hashlib.sha256(raw).hexdigest() + "  " + str(len(raw)) + " bytes ===")
        print(raw.decode("utf-8", "replace"))
        print("=== end of " + rel + " ===")
    if failed:
        print("SECTION READ INCOMPLETE. STOP and report.")
        return 1
    print("SECTION " + n + " READ COMPLETE: " + str(len(files)) + " file(s).")
    return 0


def report():
    proj_real = os.environ.get("CLAUDE_PROJECT_DIR", os.getcwd())
    try:
        head = subprocess.run(["git", "rev-parse", "--short", "HEAD"], cwd=proj_real,
                              capture_output=True, text=True, check=True).stdout.strip()
        st = subprocess.run(["git", "status", "--porcelain", "--untracked-files=all"], cwd=proj_real,
                            capture_output=True, text=True, check=True).stdout
    except Exception as e:
        print("REPORT FAILED: git did not run (" + type(e).__name__ + "). STOP and report.")
        return 1
    print("Work copy HEAD: " + head)
    rows = 0
    for line in st.splitlines():
        if len(line) < 4:
            continue
        status, rel = line[:2], line[3:].strip().strip('"')
        if " -> " in rel:
            rel = rel.split(" -> ", 1)[1].strip().strip('"')
        r = norm(rel)
        if r in HARNESS_FILES or r.startswith((".claude/",)):
            continue
        full = os.path.join(proj_real, rel)
        if os.path.isfile(full):
            print(status + "  " + rel + "  SHA-256 " + sha(full) + "  " + str(os.path.getsize(full)) + " bytes")
        else:
            print(status + "  " + rel + "  (deleted)")
        rows += 1
    print("Changed or added files (harness excluded): " + str(rows))
    return 0


def main():
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    mode = sys.argv[1] if len(sys.argv) > 1 else ""
    try:
        if mode == "pretool":
            pretool()
        elif mode == "reinject":
            reinject()
            sys.exit(0)
        elif mode == "section" and len(sys.argv) > 2:
            sys.exit(section(sys.argv[2]))
        elif mode == "report":
            sys.exit(report())
        else:
            print("usage: nh_guard.py pretool | reinject | section N | report", file=sys.stderr)
            sys.exit(2 if mode == "pretool" else 1)
    except SystemExit:
        raise
    except Exception as e:
        if mode == "pretool":
            print("BLOCKED by N.H guard: the guard itself failed (" + type(e).__name__ + ": " + str(e) +
                  "). Fail-closed. Stop and report.", file=sys.stderr)
            sys.exit(2)
        print("N.H guard error: " + type(e).__name__ + ": " + str(e), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
