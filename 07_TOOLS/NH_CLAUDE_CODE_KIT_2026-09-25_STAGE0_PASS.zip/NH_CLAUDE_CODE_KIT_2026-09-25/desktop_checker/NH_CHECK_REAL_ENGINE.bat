@echo off
title NH real engine check
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0NH_CHECK_REAL_ENGINE.ps1"
echo.
pause
