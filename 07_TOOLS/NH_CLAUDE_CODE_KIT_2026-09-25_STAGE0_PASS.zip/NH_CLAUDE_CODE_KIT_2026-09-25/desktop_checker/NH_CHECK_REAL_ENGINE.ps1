# NH_CHECK_REAL_ENGINE.ps1  -  version 1.0, 2026-09-25, written by Claude (chat) for Ness.
#
# READ-ONLY. This script only looks. It never writes, moves or deletes anything
# in the engine folder or the work folder. It writes exactly one file: a report
# on your Desktop, so you can drag it into the chat if the answer is STOP.
#
# It checks:
#   1. The 8 sealed stores still have the exact fingerprints recorded on 2026-09-25.
#   2. The seal marker .nh_roots.sealed is still there and still empty.
#   3. Files that must never exist still do not exist.
#   4. The work folder has no commit except its baseline.
#
# If a future approved change ever alters a store on purpose, this checker must
# get a new version with the new fingerprints. It is never edited in place.

param(
    [string]$Engine = "C:\Users\user\nh_engine_core",
    [string]$Work   = "C:\Users\user\nh_cc_work",
    [string]$ReportDir = [Environment]::GetFolderPath("Desktop")
)

$expected = [ordered]@{
    ".nh_accretive_store.jsonl"     = "BEDAF9EE2311EFB02D5E6D1D749449A0FB5FC28243775455B0AE1595E4A9CABE"
    ".nh_readings_quarantine.jsonl" = "03E6A2539CEDFAAD2ADF6ADA0DF3F6DC432DEC0629E2D4E71A675779441B24F3"
    ".nh_retry_state.jsonl"         = "B85237F9610B9FAC5D6467393DB6CE2C0B3A2866F89CD4A3B3EA75FA3EEACE43"
    ".nh_retry_log_b9.jsonl"        = "A40E8B1F29DD882F61BE156C085D62F15890E718416FCD7D75258F4D9AC99D57"
    ".nh_reread_state.jsonl"        = "CB283C20AE4AE03F39D2F513AA3D452F97F30DA873267A82F5F72C930630FEB1"
    ".nh_reread_log_b10.jsonl"      = "E2A3FCB9F1F071EBEBB2EC0643816C5E80A619B4B20A951B9082D9B770235686"
    ".nh_bhold_state.jsonl"         = "B6D9A0F70F1058496CCB531A82B628AA585618857ED025D7B68845B44B242BBF"
    ".nh_bhold_log.jsonl"           = "79B66C6AE66FD9662B18BDB14BD0CAF60B33AA5D71CC4E5C43A917EBBD6325FA"
}
$mustNotExist = @(
    ".nh_readings_store.jsonl",
    ".nh_readings_production_authorized",
    ".nh_a25_mode_rule.json",
    ".nh_a29_policy.json"
)

$lines = New-Object System.Collections.Generic.List[string]
$problems = 0
function Note([string]$text) { $script:lines.Add($text) }
function Bad([string]$text)  { $script:lines.Add("PROBLEM: " + $text); $script:problems++ }

$stamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
Note ("NH REAL ENGINE CHECK  v1.0  run at " + $stamp)
Note ("Engine folder: " + $Engine)
Note ("Work folder:   " + $Work)
Note ""

# 1. The 8 stores
Note "1. The 8 sealed stores"
foreach ($name in $expected.Keys) {
    $path = Join-Path $Engine $name
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        Bad ("missing store " + $name)
        continue
    }
    $hash = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
    if ($hash -eq $expected[$name]) {
        Note ("   same     " + $name + "  " + $hash)
    } else {
        Bad ("CHANGED  " + $name + "  now " + $hash + "  expected " + $expected[$name])
    }
}
Note ""

# 2. The seal
Note "2. The seal marker"
$seal = Join-Path $Engine ".nh_roots.sealed"
if (-not (Test-Path -LiteralPath $seal -PathType Leaf)) {
    Bad ".nh_roots.sealed is missing"
} else {
    # -Force: a name starting with a dot can count as hidden. Any failure to read = problem.
    try { $sealLen = (Get-Item -LiteralPath $seal -Force -ErrorAction Stop).Length }
    catch { $sealLen = -1 }
    if ($sealLen -ne 0) {
        Bad (".nh_roots.sealed is not empty or could not be read (size " + $sealLen + ")")
    } else {
        Note "   present and empty"
    }
}
Note ""

# 3. Files that must never exist
Note "3. Files that must never exist"
foreach ($name in $mustNotExist) {
    if (Test-Path -LiteralPath (Join-Path $Engine $name)) { Bad ($name + " exists") }
    else { Note ("   absent   " + $name) }
}
$b11 = @(Get-ChildItem -LiteralPath $Engine -Force -Filter ".nh_b11*" -ErrorAction SilentlyContinue)
if ($b11.Count -gt 0) { Bad (".nh_b11 batch files exist: " + (($b11 | ForEach-Object { $_.Name }) -join ", ")) }
else { Note "   absent   .nh_b11* (batch files)" }
Note ""

# 4. The work folder
Note "4. The work folder"
if (-not (Test-Path -LiteralPath (Join-Path $Work ".git"))) {
    Note "   no work folder git found - skipped"
} else {
    $log = @(& git -C $Work log --oneline 2>&1)
    if ($LASTEXITCODE -ne 0) {
        Bad ("could not read the work folder history: " + ($log -join " "))
    } elseif ($log.Count -ne 1) {
        Bad ("the work folder has " + $log.Count + " commits; only the baseline is allowed: " + ($log -join " | "))
    } else {
        Note ("   only the baseline commit: " + $log[0])
    }
}
Note ""

if ($problems -eq 0) { $verdict = "ALL GOOD - your real engine is untouched." }
else { $verdict = "STOP - " + $problems + " problem(s). Drag the report file into the chat." }
Note ("RESULT: " + $verdict)

$report = Join-Path $ReportDir ("NH_CHECK_" + (Get-Date -Format "yyyy-MM-dd_HH-mm-ss") + ".txt")
$lines | Set-Content -LiteralPath $report -Encoding UTF8

foreach ($l in $lines) {
    if ($l.StartsWith("PROBLEM")) { Write-Host $l -ForegroundColor Red } else { Write-Host $l }
}
Write-Host ""
if ($problems -eq 0) {
    Write-Host "  ##########################################" -ForegroundColor Green
    Write-Host "  #   ALL GOOD - your real engine is safe   #" -ForegroundColor Green
    Write-Host "  ##########################################" -ForegroundColor Green
} else {
    Write-Host "  ##########################################" -ForegroundColor Red
    Write-Host "  #   STOP - something changed              #" -ForegroundColor Red
    Write-Host "  #   Drag the report file into the chat    #" -ForegroundColor Red
    Write-Host "  ##########################################" -ForegroundColor Red
}
Write-Host ""
Write-Host ("Report saved: " + $report)
